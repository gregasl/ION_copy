package com.iontrading.samples.advanced.orderManagement;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.FileHandler;
import java.util.logging.Formatter;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.util.logging.Logger;

/**
 * AsyncLoggingManager provides high-performance asynchronous logging
 * for the trading system. It offloads logging operations to a dedicated
 * thread to prevent blocking in critical trading paths.
 */
public class AsyncLoggingManager {
    
    private static final String LOG_DIRECTORY = "logs";
    private static final int DEFAULT_QUEUE_SIZE = 500000; // Large queue to handle bursts
    private static final int DEFAULT_LOG_FILE_SIZE = 20 * 1024 * 1024; // 10 MB
    private static final int DEFAULT_LOG_FILE_COUNT = 10;
    private static final long SHUTDOWN_TIMEOUT_MS = 5000; // 5 seconds
    
    // Thread pool for async logging
    private final ExecutorService loggingExecutor;
    // Statistics for monitoring
    private final AtomicLong messagesQueued = new AtomicLong(0);
    private final AtomicLong messagesProcessed = new AtomicLong(0);
    private final AtomicLong queueOverflows = new AtomicLong(0);
    
    // Singleton instance
    private static AsyncLoggingManager instance;
    
    /**
     * Get the singleton instance of AsyncLoggingManager
     */
    public static synchronized AsyncLoggingManager getInstance() {
        if (instance == null) {
            instance = new AsyncLoggingManager();
        }
        return instance;
    }
    
    /**
     * Private constructor to enforce singleton pattern
     */
    private AsyncLoggingManager() {
        // Create a thread pool with a single worker thread for logging
        BlockingQueue<Runnable> workQueue = new ArrayBlockingQueue<>(DEFAULT_QUEUE_SIZE);
        
        ThreadFactory threadFactory = r -> {
            Thread t = new Thread(r, "AsyncLogging-Worker");
            t.setDaemon(true); // Make it a daemon thread so it doesn't prevent JVM shutdown
            return t;
        };
        
        // Custom rejection handler to track queue overflows
        RejectedExecutionHandler rejectionHandler = (runnable, executor) -> {
            queueOverflows.incrementAndGet();
            // Log to console that we're dropping a log message
            System.err.println("WARNING: Async logging queue full, dropping log message");
            
            // Option: You could use a direct synchronous log here to ensure critical messages
            // are not lost, but this would block the calling thread
            // if (runnable instanceof LogTask) {
            //     ((LogTask) runnable).logDirect();
            // }
        };
        
        // Create a thread pool with a single worker, custom queue size, and rejection handler
        ThreadPoolExecutor executor = new ThreadPoolExecutor(
                1, 1, // Core and max pool size of 1
                0L, TimeUnit.MILLISECONDS, // Keep alive time
                workQueue,
                threadFactory,
                rejectionHandler);
        
        loggingExecutor = executor;
        
        // Create logs directory if it doesn't exist
        File logDir = new File(LOG_DIRECTORY);
        if (!logDir.exists()) {
            logDir.mkdirs();
        }
        
        // Add shutdown hook to flush remaining logs
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            shutdown();
        }));
    }
    
    /**
     * Initialize file logging for the application
     * @param logFileName The name of the log file
     */
    public void setupFileLogging(String logFileName) {
        try {
            // Create the logs directory if it doesn't exist
            File logDir = new File(LOG_DIRECTORY);
            if (!logDir.exists()) {
                logDir.mkdirs();
            }
            
            // Set up the file handler
            FileHandler fileHandler = new FileHandler(
                    "logs/" + logFileName,
                    DEFAULT_LOG_FILE_SIZE,
                    DEFAULT_LOG_FILE_COUNT,
                    true);
            
            // Use custom formatter for better performance
            fileHandler.setFormatter(new HighPerformanceFormatter());
            
            // Add handler to the root logger
            Logger rootLogger = Logger.getLogger("");
            
            // Remove existing handlers
            for (Handler handler : rootLogger.getHandlers()) {
                rootLogger.removeHandler(handler);
            }
            
            // Set global logging level
            rootLogger.setLevel(Level.INFO);
            
            // Add our handler
            rootLogger.addHandler(fileHandler);
            
            // Set specific loggers for our classes with higher detail level
            Logger orderMgmtLogger = Logger.getLogger("com.iontrading.samples.advanced.orderManagement");
            orderMgmtLogger.setLevel(Level.FINE);
            
            log(orderMgmtLogger, Level.INFO, "Asynchronous file logging initialized to: logs/" + logFileName);
        } catch (SecurityException | IOException e) {
            e.printStackTrace();
            System.err.println("Failed to initialize file logging: " + e.getMessage());
        }
    }
    
    /**
     * Log a message asynchronously
     * 
     * @param logger The logger to use
     * @param level The log level
     * @param message The message to log
     */
    public void log(Logger logger, Level level, String message) {
        // Skip if the level is not loggable
        if (!logger.isLoggable(level)) {
            return;
        }
        
        // Count the message as queued
        messagesQueued.incrementAndGet();
        
        // Create a log task and submit it to the executor
        loggingExecutor.execute(new LogTask(logger, level, message));
    }
    
    /**
     * Log a message with an exception asynchronously
     * 
     * @param logger The logger to use
     * @param level The log level
     * @param message The message to log
     * @param thrown The exception to log
     */
    public void log(Logger logger, Level level, String message, Throwable thrown) {
        // Skip if the level is not loggable
        if (!logger.isLoggable(level)) {
            return;
        }
        
        // Count the message as queued
        messagesQueued.incrementAndGet();
        
        // Create a log task and submit it to the executor
        loggingExecutor.execute(new LogTask(logger, level, message, thrown));
    }
    
    /**
     * Get the number of messages queued for logging
     */
    public long getMessagesQueued() {
        return messagesQueued.get();
    }
    
    /**
     * Get the number of messages processed
     */
    public long getMessagesProcessed() {
        return messagesProcessed.get();
    }
    
    /**
     * Get the number of times the queue has overflowed
     */
    public long getQueueOverflows() {
        return queueOverflows.get();
    }
    
    /**
     * Get the current queue size (messages waiting to be processed)
     */
    public int getCurrentQueueSize() {
        if (loggingExecutor instanceof ThreadPoolExecutor) {
            return ((ThreadPoolExecutor) loggingExecutor).getQueue().size();
        }
        return -1; // Unknown
    }
    
    /**
     * Shutdown the logging executor, waiting for queued logs to be processed
     */
    public void shutdown() {
        System.out.println("Shutting down AsyncLoggingManager, processing remaining " + 
                          getCurrentQueueSize() + " log messages...");
        
        loggingExecutor.shutdown();
        try {
            // Wait for existing tasks to terminate
            if (!loggingExecutor.awaitTermination(SHUTDOWN_TIMEOUT_MS, TimeUnit.MILLISECONDS)) {
                System.err.println("AsyncLoggingManager shutdown timed out. " + 
                                  (messagesQueued.get() - messagesProcessed.get()) + 
                                  " messages may be lost.");
                loggingExecutor.shutdownNow();
            }
        } catch (InterruptedException e) {
            // (Re-)Cancel if current thread also interrupted
            loggingExecutor.shutdownNow();
            // Preserve interrupt status
            Thread.currentThread().interrupt();
        }
        
        System.out.println("AsyncLoggingManager shutdown complete. " +
                          "Processed " + messagesProcessed.get() + "/" + messagesQueued.get() + 
                          " messages. Overflows: " + queueOverflows.get());
    }
    
    /**
     * Task for asynchronous logging
     */
    private class LogTask implements Runnable {
        private final Logger logger;
        private final Level level;
        private final String message;
        private final Throwable thrown;
        private final long timestamp;
        
        public LogTask(Logger logger, Level level, String message) {
            this(logger, level, message, null);
        }
        
        public LogTask(Logger logger, Level level, String message, Throwable thrown) {
            this.logger = logger;
            this.level = level;
            this.message = message;
            this.thrown = thrown;
            this.timestamp = System.currentTimeMillis();
        }
        
        @Override
        public void run() {
            try {
                // Create a log record with the captured timestamp
                LogRecord record = new LogRecord(level, message);
                record.setLoggerName(logger.getName());
                record.setMillis(timestamp);
                record.setThrown(thrown);
                
                // Get the class name from the logger name
                String loggerName = logger.getName();
                String className = loggerName;
                if (loggerName.contains(".")) {
                    className = loggerName.substring(loggerName.lastIndexOf('.') + 1);
                }
                record.setSourceClassName(className);
                
                // Log directly to handlers to bypass the logger's synchronization
                for (Handler handler : logger.getHandlers()) {
                    handler.publish(record);
                }
                
                // Also log to parent handlers if needed
                Logger parent = logger.getParent();
                if (parent != null) {
                    for (Handler handler : parent.getHandlers()) {
                        handler.publish(record);
                    }
                }
                
                // Increment the processed count
                messagesProcessed.incrementAndGet();
            } catch (Exception e) {
                // If an exception occurs during logging, print to stderr
                System.err.println("Error in async logging: " + e.getMessage());
                e.printStackTrace();
            }
        }
        
        /**
         * Perform direct synchronous logging (used when queue is full)
         */
        public void logDirect() {
            if (thrown != null) {
                logger.log(level, message, thrown);
            } else {
                logger.log(level, message);
            }
            // Still count as processed
            messagesProcessed.incrementAndGet();
        }
    }
    
    /**
     * High-performance formatter that minimizes string operations
     */
    private static class HighPerformanceFormatter extends Formatter {
        private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        
        @Override
        public String format(LogRecord record) {
            StringBuilder sb = new StringBuilder(256);
            
            // Format: timestamp [level] class: message
            sb.append(dateFormat.format(new Date(record.getMillis())));
            sb.append(" [");
            sb.append(record.getLevel().getName());
            sb.append("] ");
            sb.append(record.getSourceClassName());
            sb.append(": ");
            sb.append(formatMessage(record));
            sb.append(System.lineSeparator());
            
            // Add exception if present
            if (record.getThrown() != null) {
                try {
                    Throwable thrown = record.getThrown();
                    sb.append(thrown.toString());
                    sb.append(System.lineSeparator());
                    
                    // Add stack trace elements
                    for (StackTraceElement element : thrown.getStackTrace()) {
                        sb.append("    at ");
                        sb.append(element.toString());
                        sb.append(System.lineSeparator());
                    }
                } catch (Exception ex) {
                    sb.append("Error formatting exception: ");
                    sb.append(ex.toString());
                    sb.append(System.lineSeparator());
                }
            }
            
            return sb.toString();
        }
    }
}