package com.iontrading.samples.advanced.orderManagement;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * This class provides a centralized way to initialize and configure
 * asynchronous logging for the entire application. All components
 * should use this class instead of setting up logging individually.
 */
public class ApplicationLogging {
    
    private static final Logger LOGGER = Logger.getLogger(ApplicationLogging.class.getName());
    private static boolean initialized = false;
    
    /**
     * Initialize logging for the entire application.
     * This method should be called once at application startup,
     * before any other logging operations.
     * 
     * @param applicationName Name of the application (used for log file naming)
     * @return true if initialization was successful, false otherwise
     */
    public static synchronized boolean initialize(String applicationName) {
        if (initialized) {
            System.out.println("Logging already initialized");
            return true;
        }
        
        try {
            // Initialize the AsyncLoggingManager
            AsyncLoggingManager manager = AsyncLoggingManager.getInstance();
            manager.setupFileLogging(applicationName + ".log");
            
            // Log initialization success
            logAsync(LOGGER, Level.INFO, "Asynchronous logging initialized for " + applicationName);
            
            // Register shutdown hook to ensure logs are flushed
            Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                logAsync(LOGGER, Level.INFO, "Application shutting down, flushing logs");
                manager.shutdown();
            }));
            
            initialized = true;
            return true;
            
        } catch (Exception e) {
            System.err.println("Failed to initialize logging: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Log a message asynchronously.
     * This is the main method that all components should use for logging.
     * 
     * @param logger The logger to use
     * @param level The log level
     * @param message The message to log
     */
    public static void logAsync(Logger logger, Level level, String message) {
        if (!initialized) {
            // Fall back to synchronous logging if not initialized
            logger.log(level, message);
            return;
        }
        
        AsyncLoggingManager.getInstance().log(logger, level, message);
    }
    
    /**
     * Log a message with an exception asynchronously.
     * 
     * @param logger The logger to use
     * @param level The log level
     * @param message The message to log
     * @param thrown The exception to log
     */
    public static void logAsync(Logger logger, Level level, String message, Throwable thrown) {
        if (!initialized) {
            // Fall back to synchronous logging if not initialized
            logger.log(level, message, thrown);
            return;
        }
        
        AsyncLoggingManager.getInstance().log(logger, level, message, thrown);
    }
    
    /**
     * Get logging statistics for monitoring.
     * 
     * @return String containing current logging statistics
     */
    public static String getStatistics() {
        if (!initialized) {
            return "Logging not initialized";
        }
        
        AsyncLoggingManager manager = AsyncLoggingManager.getInstance();
        return String.format(
            "Logging stats: queued=%d, processed=%d, overflows=%d, queueSize=%d",
            manager.getMessagesQueued(),
            manager.getMessagesProcessed(),
            manager.getQueueOverflows(),
            manager.getCurrentQueueSize()
        );
    }
    
    /**
     * Log statistics about the logging system.
     * Useful for periodic monitoring.
     * 
     * @param level The log level to use
     */
    public static void logStatistics(Level level) {
        if (!initialized) {
            return;
        }
        
        logAsync(LOGGER, level, getStatistics());
    }
}