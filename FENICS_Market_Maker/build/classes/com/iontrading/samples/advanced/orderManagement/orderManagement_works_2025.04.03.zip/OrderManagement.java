/*
 * OrderManagement
 *
 * OrderManagement object starts the component, register the relevant listeners
 * then subscribes to the depths of the configured instruments and to the orders
 * chain.
 * The set up of the subscription is done in onPublishIdle in order to not perform
 * expensive calculations in the onPublish method.
 */

package com.iontrading.samples.advanced.orderManagement;

import java.util.Set;
import java.util.Date;
import java.util.HashSet;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.text.SimpleDateFormat;

import com.iontrading.mkv.Mkv;
import com.iontrading.mkv.MkvChain;
import com.iontrading.mkv.MkvObject;
import com.iontrading.mkv.MkvPattern;
import com.iontrading.mkv.MkvPublishManager;
import com.iontrading.mkv.MkvRecord;
import com.iontrading.mkv.MkvSupply;
import com.iontrading.mkv.enums.MkvChainAction;
import com.iontrading.mkv.enums.MkvObjectType;
import com.iontrading.mkv.events.MkvChainListener;
import com.iontrading.mkv.events.MkvPublishListener;
import com.iontrading.mkv.events.MkvRecordListener;
import com.iontrading.mkv.exceptions.MkvException;
import com.iontrading.mkv.qos.MkvQoS;

/**
 * OrderManagement is the main component of the system.
 */
public class OrderManagement implements MkvPublishListener, MkvRecordListener,
    MkvChainListener, IOrderManager {

  // Add logger for debugging
  private static final Logger LOGGER = Logger.getLogger(OrderManagement.class.getName());

  // Instance of InstrumentSubscriber to load and access instrument data
  private static InstrumentSubscriber instrumentSubscriber;

  //Map to track which instrument pairs we've already traded
  private final Map<String, Long> lastTradeTimeByInstrument = new ConcurrentHashMap<>();
  //Minimum time between trades for the same instrument (milliseconds)
  private static final long MIN_TRADE_INTERVAL_MS = 1000; // 1 second
  //Flag to enable or disable continuous trading
  private boolean continuousTradingEnabled = true;
  //Timer for periodic market rechecks
  private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
  //Cache of the latest best prices by instrument
  private final Map<String, Best> latestBestByInstrument = new ConcurrentHashMap<>();
  
  private final Map<String, String> venueToTraderMap = new HashMap<>();
  Set<String> validVenues = new HashSet<>(Arrays.asList("DEALERWEB_REPO", "BTEC_REPO_US", "FENICS_USREPO"));
  
  private final ScheduledExecutorService heartbeatScheduler = Executors.newScheduledThreadPool(1);
  
  // Timeout for instrument data loading (in seconds)
  private static final int INSTRUMENT_DATA_TIMEOUT = 30;
  private static final String CM_SOURCE = "VMO_REPO_US";
  private static final String PATTERN = "USD.CM_DEPTH." + CM_SOURCE + ".";

  /**
   * Main method to start the application.
   * Initializes the MKV API and sets up subscriptions.
   */
  public static void main(String[] args) {
      // Initialize centralized logging before anything else
      try {
          System.out.println("### STARTUP: Beginning application initialization");
    	  if (!ApplicationLogging.initialize("orderManagement")) {
    		  System.err.println("Failed to initialize logging, exiting");
    		  System.exit(1);
    	  }

//    	    Examples setting global logging levels, choices are:
//    	  	FINEST
//    	  	FINER
//    	  	FINE
//    	  	CONFIG
//    	  	INFO
//    	  	WARNING
//    	  	SEVERE
//          // Set specific logger to DEBUG
//          ApplicationLogging.setLogLevel("com.iontrading.samples.advanced.orderManagement.InstrumentSubscriber", Level.FINE);
//          
//          // Set multiple loggers to a specific level
//          ApplicationLogging.setLogLevels(Level.INFO, 
//              "com.iontrading.samples.advanced.orderManagement.DepthListener",
//              "com.iontrading.samples.advanced.orderManagement.MarketOrder"
//          );
//          
//          // Set global logging level
          ApplicationLogging.setGlobalLogLevel(Level.WARNING);
    	  
    	  ApplicationLogging.logAsync(LOGGER, Level.INFO, "Starting OrderManagement");
      } catch (Exception e) {
    	  ApplicationLogging.logAsync(LOGGER, Level.SEVERE, "Failed to start: " + e.getMessage(), e);
      }

    System.out.println("### DIRECT: Creating OrderManagement instance");
    // Create the order management instance
    OrderManagement om = new OrderManagement();
    System.out.println("### DIRECT: OrderManagement instance created");    
    
    try {

    	// Get thread information
    	Thread[] threads = new Thread[Thread.activeCount()];
    	Thread.enumerate(threads);
    	System.out.println("### DIRECT: Current threads:");
    	for (Thread t : threads) {
    	    if (t != null) {
    	        System.out.println("  - " + t.getName() + " (daemon: " + t.isDaemon() + ", alive: " + t.isAlive() + ", state: " + t.getState() + ")");
    	    }
    	}
    	
    	AsyncLoggingManager manager = AsyncLoggingManager.getInstance();
    	System.out.println("### DIRECT: AsyncLoggingManager instance: " + manager);
    	System.out.println("### DIRECT: Current queue size: " + manager.getCurrentQueueSize());
    	System.out.println("### DIRECT: Messages queued: " + manager.getMessagesQueued());
    	System.out.println("### DIRECT: Messages processed: " + manager.getMessagesProcessed());
    	
      // First, initialize the InstrumentSubscriber and wait for data to load
      instrumentSubscriber = new InstrumentSubscriber(args);
      
      // Set up a force data loaded call after timeout
      Thread timeoutThread = new Thread(() -> {
          try {
              Thread.sleep(INSTRUMENT_DATA_TIMEOUT * 1000);
              if (!instrumentSubscriber.isDataLoaded()) {
                ApplicationLogging.logAsync(LOGGER, Level.WARNING, "Initializing InstrumentSubscriber");
                  instrumentSubscriber.forceDataLoaded();
              }
          } catch (InterruptedException e) {
            ApplicationLogging.logAsync(LOGGER, Level.FINE, "Timeout thread interrupted");  
          }
      });
      timeoutThread.setDaemon(true);
      timeoutThread.start();
      
      // Register a callback for when data is loaded
      instrumentSubscriber.registerDataLoadedCallback(() -> {
        ApplicationLogging.logAsync(LOGGER, Level.INFO, "Instrument data loaded successfully");  
          // No need to make these calls here since they'll be triggered by onPublishIdle events
      });
      
      // Set up the Quality of Service for the MKV API
      MkvQoS qos = new MkvQoS();
      qos.setArgs(args);
      qos.setPublishListeners(new MkvPublishListener[] { om });

      ApplicationLogging.logAsync(LOGGER, Level.INFO, "Starting MKV API");
      // Start the MKV API if it hasn't been started already
      Mkv existingMkv = Mkv.getInstance();
      if (existingMkv == null) {
          Mkv.start(qos);
      } else {
        ApplicationLogging.logAsync(LOGGER, Level.INFO, "MKV API already started");
          existingMkv.getPublishManager().addPublishListener(om);
      }

      // Wait for instrument data to be loaded, but with a timeout
      ApplicationLogging.logAsync(LOGGER, Level.INFO, "Waiting for instrument data to be loaded...");
      boolean dataLoaded = false;
      try {
          for (int i = 0; i < INSTRUMENT_DATA_TIMEOUT; i++) {
              if (instrumentSubscriber.isDataLoaded()) {
                  dataLoaded = true;
                  ApplicationLogging.logAsync(LOGGER, Level.INFO, "Instrument data loaded successfully");
                  break;
              }
              Thread.sleep(1000); // Check once per second
          }
          
          if (!dataLoaded) {
            ApplicationLogging.logAsync(LOGGER, Level.WARNING, "Timeout waiting for instrument data");  
          }
      } catch (InterruptedException e) {
        ApplicationLogging.logAsync(LOGGER, Level.SEVERE, "Interrupted while waiting for instrument data: " + e.getMessage());  
          Thread.currentThread().interrupt();
      }
     
      ApplicationLogging.logAsync(LOGGER, Level.INFO, "Setting up depths subscriptions");
      om.subscribeToDepths();
    } catch (MkvException e) {
      ApplicationLogging.logAsync(LOGGER, Level.SEVERE, "Failed to start MKV API: " + e.getMessage(), e);
      e.printStackTrace();
    }
  }
    
  /**
   * Gets the native instrument ID for a source.
   * This delegates to the InstrumentSubscriber.
   * 
   * @param instrumentId The instrument identifier
   * @param sourceId The source identifier
   * @return The native instrument ID or null if not found
   */
  public static String getNativeInstrumentId(String instrumentId, String sourceId) {
    if (instrumentSubscriber != null) {
      return instrumentSubscriber.getInstrumentFieldBySourceString(instrumentId, sourceId);
    }
    ApplicationLogging.logAsync(LOGGER, Level.WARNING, "InstrumentSubscriber not initialized - cannot get native instrument ID");
    return null;
  }
  
  /**
   * Map to cache market orders by their request ID.
   * This allows tracking orders throughout their lifecycle.
   */
  private final Map<Integer, MarketOrder> orders = new HashMap<>();

  /**
   * Unique identifier for this instance of the application.
   * Used to identify orders placed by this component.
   */
  private final String applicationId;

  /**
   * Creates a new instance of OrderManagement.
   * Generates a unique application ID based on the current time.
   */
  public OrderManagement() {
    // Generate a hex representation of the current time (last 3 digits)
    // This provides a reasonably unique ID for this instance
    applicationId = "Java_Order_Manager"; 
    ApplicationLogging.logAsync(LOGGER, Level.INFO, "Application ID: " + applicationId);
        
    // Initialize venue to trader mapping
    initializeTraderMap();
    
    // Initialize one minute heartbeats
    initializeHeartbeat();
    
    // Set up the shutdown hook
    setupShutdownHook();

    // Initialize the market recheck scheduler
    initializeMarketRechecks();
  }

  /**
   * Returns the unique application ID for this instance.
   * This is used to identify orders placed by this component.
   */
  public String getApplicationId() {
    return applicationId;
  }

  /**
   * Gets the InstrumentSubscriber instance.
   * 
   * @return The InstrumentSubscriber or null if not initialized
   */
  public static InstrumentSubscriber getInstrumentSubscriber() {
      return instrumentSubscriber;
  }
  
  // Initialize the mapping of venues to trader IDs
  private void initializeTraderMap() {
      venueToTraderMap.put("BTEC_REPO_US", "TEST2");
      venueToTraderMap.put("DEALERWEB_REPO", "asldevtrd1");
      venueToTraderMap.put("FENICS_REPO", "frosasl1");
      // Add more venue-trader mappings as needed
      
      ApplicationLogging.logAsync(LOGGER, Level.INFO, "Venue to trader mapping initialized with " + 
                                  venueToTraderMap.size() + " entries");
  }
  
	//Helper method to get trader ID for a venue
	private String getTraderForVenue(String venue) {
	   String traderId = venueToTraderMap.get(venue);
	   if (traderId == null) {
	       ApplicationLogging.logAsync(LOGGER, Level.WARNING, "No trader configured for venue: " + venue);
	       return "DEFAULT_TRADER"; // Fallback trader ID
	   }
	   return traderId;
	}
  
  /**
   * Called when a publication event occurs.
   * This implementation doesn't handle individual publication events.
   */
  public void onPublish(MkvObject mkvObject, boolean pub_unpub, boolean dwl) {
    // Not handling individual publication events
    if (LOGGER.isLoggable(Level.FINEST)) {
      ApplicationLogging.logAsync(LOGGER, Level.FINEST, "Publication event for: " + mkvObject.getName());
    }
  }

  /**
   * Called when a publication download is complete.
   * This is where we set up the order chain subscription and
   * potentially send an initial FAS order if configured.
   * 
   * @param component The component name
   * @param start Whether this is the start of idle time
   */
  public void onPublishIdle(String component, boolean start) {
    if (LOGGER.isLoggable(Level.FINEST)) {
      ApplicationLogging.logAsync(LOGGER, Level.FINEST, "Publication idle for component: " + component + ", start: " + start);
    }
  }

  /**
   * Sets up subscriptions to depth records using a pattern-based approach.
   * Subscribes to the consolidated market data from VMO_REPO_US.
   */
  public void subscribeToDepths() {
      // Subscribe to consolidated depth data from VMO_REPO_US regardless of what's in MarketDef.CM_SOURCE
      if (LOGGER.isLoggable(Level.INFO)) {
        ApplicationLogging.logAsync(LOGGER, Level.INFO, "Subscribing to consolidated depth data using pattern: " + PATTERN);
      }    
      try {
          // Get the publish manager to access patterns
          MkvPublishManager pm = Mkv.getInstance().getPublishManager();
          
          // Look up the pattern object
          MkvObject obj = pm.getMkvObject(PATTERN);
          
          if (obj != null && obj.getMkvObjectType().equals(MkvObjectType.PATTERN)) {
              // Create a depth listener that will handle all instruments
              DepthListener depthListener = new DepthListener(this);
              
              // Subscribe to the pattern with the depth fields
              if (LOGGER.isLoggable(Level.INFO)) {
                ApplicationLogging.logAsync(LOGGER, Level.INFO, "Found consolidated depth pattern, subscribing: " + PATTERN);
              }
              ((MkvPattern) obj).subscribe(MarketDef.DEPTH_FIELDS, depthListener);
              if (LOGGER.isLoggable(Level.INFO)) {
                ApplicationLogging.logAsync(LOGGER, Level.INFO, "Successfully subscribed to consolidated depth pattern");
              }
          } else {
            ApplicationLogging.logAsync(LOGGER, Level.WARNING, "Consolidated depth pattern not found: " + PATTERN);  
          }
              // Set up a publish listener to catch the pattern when it appears
              pm.addPublishListener(new MkvPublishListener() {
                  @Override
                  public void onPublish(MkvObject mkvObject, boolean pub_unpub, boolean dwl) { }
                  
                  @Override
                  public void onPublishIdle(String component, boolean start) {
                      if (!start) {
                          // Check again for the pattern when download is complete
                          if (obj != null && obj.getMkvObjectType().equals(MkvObjectType.PATTERN)) {
                              try {
                                if (LOGGER.isLoggable(Level.INFO)) {
                                  ApplicationLogging.logAsync(LOGGER, Level.INFO, "Found consolidated depth pattern during idle: " + PATTERN);
                                }
                                  // Subscribe to the pattern with the depth fields
                                  ((MkvPattern) obj).subscribe(MarketDef.DEPTH_FIELDS, new DepthListener(OrderManagement.this));
                                  if (LOGGER.isLoggable(Level.INFO)) {
                                    ApplicationLogging.logAsync(LOGGER, Level.INFO, "Successfully subscribed to consolidated depth pattern during idle");  
                                  }
                              } catch (Exception e) {
                                ApplicationLogging.logAsync(LOGGER, Level.SEVERE, "Error subscribing to consolidated depth pattern during idle: " + e.getMessage(), e);
                                  // Handle any exceptions that occur during subscription  
                                  e.printStackTrace();
                              }
                          }
                      }
                  }
                  
                  @Override
                  public void onSubscribe(MkvObject mkvObject) {
                      // Not needed
                  }
              });
          }
       catch (Exception e) {
        ApplicationLogging.logAsync(LOGGER, Level.SEVERE, "Error setting up depth subscriptions: " + e.getMessage(), e);
          // Handle any exceptions that occur during subscription
          e.printStackTrace();
      }
  }
        
  /**
   * Not interested in this event because our component is a pure subscriber
   * and is not supposed to receive requests for subscriptions.
   */
  public void onSubscribe(MkvObject mkvObject) {
    // No action needed - we are not a publisher
    if (LOGGER.isLoggable(Level.FINEST)) {
      ApplicationLogging.logAsync(LOGGER, Level.FINEST, "Subscription event for: " + mkvObject.getName());
    }
  }

  /**
   * Caches a MarketOrder record using the request ID as key.
   * This allows us to track the order throughout its lifecycle.
   * 
   * @param order The MarketOrder to cache
   */
  private void addOrder(MarketOrder order) {
    if (LOGGER.isLoggable(Level.FINE)) {
      ApplicationLogging.logAsync(LOGGER, Level.FINE, "Adding order to cache: reqId=" + order.getMyReqId());
    }
    orders.put(Integer.valueOf(order.getMyReqId()), order);
  }

  /**
   * Removes a MarketOrder object from the cache by request ID.
   * Called when an order is considered "dead".
   * 
   * @param reqId The request ID of the order to remove
   */
  public void removeOrder(int reqId) {
    if (LOGGER.isLoggable(Level.FINE)) {
      ApplicationLogging.logAsync(LOGGER, Level.FINE, "Removing order from cache: reqId=" + reqId);
    }
    orders.remove(Integer.valueOf(reqId));
  }

  /**
   * Retrieves a MarketOrder object from the cache by request ID.
   * 
   * @param reqId The request ID of the order to retrieve
   * @return The MarketOrder object or null if not found
   */
  public MarketOrder getOrder(int reqId) {
    MarketOrder order = orders.get(Integer.valueOf(reqId));
    if (LOGGER.isLoggable(Level.FINE)) {
      ApplicationLogging.logAsync(LOGGER, Level.FINE, "Retrieving order from cache: reqId=" + reqId + 
               ", found=" + (order != null));
    }
    return order;
  }

  /**
   * The component doesn't need to listen to partial updates for records.
   */
  public void onPartialUpdate(MkvRecord mkvRecord, MkvSupply mkvSupply,
      boolean isSnap) {
    // Not interested in partial updates
    if (LOGGER.isLoggable(Level.FINEST)) {
      ApplicationLogging.logAsync(LOGGER, Level.FINEST, "Partial update for record: " + mkvRecord.getName());
    }
  }

  /**
   * Processes full updates for CM_ORDER records.
   * If the update is for an order placed by this component
   * (based on UserData and FreeText), forwards the update to the
   * appropriate MarketOrder object.
   */
  public void onFullUpdate(MkvRecord mkvRecord, MkvSupply mkvSupply,
      boolean isSnap) {
    try {
      // Get the UserData (contains our request ID) and FreeText (contains our application ID)
      String userData = mkvRecord.getValue("UserData").getString();
      String freeText = mkvRecord.getValue("FreeText").getString();
      
      // If this order wasn't placed by us, ignore it
      if ("".equals(userData) || !freeText.equals(getApplicationId())) {
        if (LOGGER.isLoggable(Level.FINEST)) {
          ApplicationLogging.logAsync(LOGGER, Level.FINEST, "Ignoring order update for non-matching order: " + 
                     mkvRecord.getName() + ", userData=" + userData + 
                     ", freeText=" + freeText);
        }
        return;
      } else {
        // This is an order we placed - forward the update to the MarketOrder
        try {
          // Parse the request ID from the UserData
          int reqId = Integer.parseInt(userData);
          if (LOGGER.isLoggable(Level.FINE)) {
            ApplicationLogging.logAsync(LOGGER, Level.FINE, "Processing order update: reqId=" + reqId);
          }        
          // Get the corresponding MarketOrder from the cache
          MarketOrder order = getOrder(reqId);
          
          if (order != null) {
            // Forward the update to the order
            if (LOGGER.isLoggable(Level.FINE)) {
              ApplicationLogging.logAsync(LOGGER, Level.FINE, "Forwarding update to order: reqId=" + reqId);
            }
            order.onFullUpdate(mkvRecord, mkvSupply, isSnap);
          } else {
            ApplicationLogging.logAsync(LOGGER, Level.WARNING, "Order not found in cache: reqId=" + reqId);
          }
        } catch (Exception e) {
          ApplicationLogging.logAsync(LOGGER, Level.SEVERE, "Error processing order update: " + e.getMessage(), e);
          e.printStackTrace();
        }
      }
    } catch (Exception e) {
      ApplicationLogging.logAsync(LOGGER, Level.SEVERE, "Error accessing order fields: " + e.getMessage(), e);
      e.printStackTrace();
    }
  }

  /**
   * Notification that an order is no longer able to trade.
   * Removes the order from the cache.
   * 
   * Implementation of IOrderManager.orderDead()
   */
  public void orderDead(MarketOrder order) {
    if (LOGGER.isLoggable(Level.INFO)) {
      ApplicationLogging.logAsync(LOGGER, Level.INFO, "Order is dead: orderId=" + order.getOrderId() + 
               ", reqId=" + order.getMyReqId());
    }  
    // Remove the order from the cache
    removeOrder(order.getMyReqId());
  }
  
  /**
   * Adds an order for the given instrument, quantity, and other parameters.
   * If the order creation succeeds, stores the order in the internal cache.
   * 
   * Implementation of IOrderManager.addOrder()
   */
  public MarketOrder addOrder(String MarketSource, String TraderId, String instrId, String verb, double qty,
      double price, String type, String tif) {
    
    // Create the order using the static factory method
    MarketOrder order = MarketOrder.orderCreate(MarketSource, TraderId, instrId, verb, qty, price,
        type, tif, this);
    
    if (order != null) {
      // If creation succeeded, add the order to the cache
      addOrder(order);
      if (LOGGER.isLoggable(Level.INFO)) {
        ApplicationLogging.logAsync(LOGGER, Level.INFO, "Order created successfully: reqId=" + order.getMyReqId() + 
                 ", instrId=" + instrId);
      }
    } else {
      ApplicationLogging.logAsync(LOGGER, Level.WARNING, "Order creation failed: instrId=" + instrId);
    }
    return order;
  }

  /**
   * Handles notification of a best price update.
   * Implementation of IOrderManager.best()
   */
	  @Override
	  public void best(Best best) {
	      // Store the latest best for this instrument
	      latestBestByInstrument.put(best.getInstrumentId(), best);
	      
	      // Process this update for potential trading
	      processMarketOpportunity(best);
	  }

	//Add this method to initialize the scheduled market rechecks
	private void initializeMarketRechecks() {
	   // Schedule a task to recheck the market every 2 seconds
	   scheduler.scheduleAtFixedRate(this::recheckMarket, 2, 2, TimeUnit.SECONDS);
	   
	   // Add a shutdown hook to clean up the scheduler
	   Runtime.getRuntime().addShutdownHook(new Thread(() -> {
      ApplicationLogging.logAsync(LOGGER, Level.INFO, "Shutting down market recheck scheduler");
	       scheduler.shutdown();
	       try {
	           if (!scheduler.awaitTermination(5, TimeUnit.SECONDS)) {
	               scheduler.shutdownNow();
	           }
	       } catch (InterruptedException e) {
	           scheduler.shutdownNow();
	           Thread.currentThread().interrupt();
	       }
	   }));
	   ApplicationLogging.logAsync(LOGGER, Level.INFO, "Market recheck scheduler initialized");
	}
	
	//Add this method to periodically recheck the market
	private void recheckMarket() {
	   if (!continuousTradingEnabled) {
	       return;
	   }
	   ApplicationLogging.logAsync(LOGGER, Level.FINE, "Rechecking market for trading opportunities");
	   	   
	   // Process each instrument's latest best price
	   for (Best best : latestBestByInstrument.values()) {
	       processMarketOpportunity(best);
	   }
	}
  
	// New method to evaluate and execute on market opportunities
	private void processMarketOpportunity(Best best) {
        if (LOGGER.isLoggable(Level.FINE)) {
//        	ApplicationLogging.logAsync(LOGGER, Level.FINE, "Processing Market Opportunity");
        }
		// Skip if the best object is null
	    if (best == null) {
	        return;
	    }
	    
	    if (best.getAsk() <= best.getBid()){
	    	return;
	    }
	    
	    // Check if this is a valid arbitrage opportunity
	    if ((best.getAskSize() >= best.getBidSizeMin()) && 
	    	    validVenues.contains(best.getAskSrc()) && 
	    	    validVenues.contains(best.getBidSrc())) {

      if (LOGGER.isLoggable(Level.INFO)) {
          ApplicationLogging.logAsync(LOGGER, Level.INFO, "Processing trading opportunity for " + best.getId() + 
                   ": ask=" + best.getAsk() + " (" + best.getAskSrc() + ")" +
                   ", bid=" + best.getBid() + " (" + best.getBidSrc() + ")");
        }
	    	
	        // Create a unique key for this instrument pair to track trades
	        String tradingKey = best.getId() + "|" + best.getAskSrc() + "|" + best.getBidSrc();
	        
	        // Check if we've traded this instrument recently
	        long currentTime = System.currentTimeMillis();
	        Long lastTradeTime = lastTradeTimeByInstrument.get(tradingKey);
	        
	        if (lastTradeTime != null && (currentTime - lastTradeTime) < MIN_TRADE_INTERVAL_MS) {
	            // Too soon to trade this instrument again
              if (LOGGER.isLoggable(Level.FINE)) {
	            ApplicationLogging.logAsync(LOGGER, Level.FINE, "Skipping trade for " + tradingKey + 
	            		" last trade was too recent: " + (currentTime - lastTradeTime) + 
                       "ms since last trade");
              }
	            return;
	        }
	        
	        // Log that we found an opportunity
          if (LOGGER.isLoggable(Level.INFO)) {
            ApplicationLogging.logAsync(LOGGER, Level.INFO, "Found trading opportunity for " + best.getId() + 
                     ": ask=" + best.getAsk() + " (" + best.getAskSrc() + ")" +
                     ", bid=" + best.getBid() + " (" + best.getBidSrc() + ")");
          }

          // Get the native instrument IDs
          String askVenueInstrument = instrumentSubscriber.getInstrumentFieldBySourceString(best.getId(), best.getAskSrc());
          String bidVenueInstrument = instrumentSubscriber.getInstrumentFieldBySourceString(best.getId(), best.getBidSrc());
          
       // Add null checks
          if (askVenueInstrument == null || bidVenueInstrument == null) {
              if (LOGGER.isLoggable(Level.WARNING)) {
                  ApplicationLogging.logAsync(LOGGER, Level.WARNING, 
                      "Missing instrument mapping for " + best.getId() + 
                      ", ask source: " + best.getAskSrc() + 
                      ", bid source: " + best.getBidSrc());
              }
              return; // Skip this opportunity
          }
          
          // Get the trader IDs for each venue
          String askTrader = getTraderForVenue(best.getAskSrc());
          String bidTrader = getTraderForVenue(best.getBidSrc());
	        
          
       // Add protection against zero or negative sizes
          if (best.getAskSize() <= 0 || best.getBidSize() <= 0) {
              ApplicationLogging.logAsync(LOGGER, Level.WARNING, 
                  "Invalid sizes detected for " + best.getId() + 
                  ": ask=" + best.getAskSize() + 
                  ", bid=" + best.getBidSize());
              return;
          }
          
          Boolean isAON = instrumentSubscriber.getInstrumentIsAON(best.getId());

          // Calculate the order size
          double orderBidSize;
          double orderAskSize;
      	  String ordertypeAsk = null;
      	  String ordertypeBid = null;
          
      	  if (Boolean.TRUE.equals(isAON)) {
        	  
              // For AON instruments, we must trade the exact size
              // Use the bid size since that's what we're selling, and we can't sell more than available
        	  orderBidSize = best.getBidSize(); 
        	  orderAskSize = best.getAskSize();
          	  
        	  if ((orderAskSize - orderBidSize) > 25) {
                  if (LOGGER.isLoggable(Level.INFO)) {
                      ApplicationLogging.logAsync(LOGGER, Level.INFO, "AON instrument detected for " + best.getId() + 
                                                 ", using ask size " + orderAskSize + " is larger than bid size: " + orderBidSize);
                  }   
                  return;
        	  }

   	        if (best.getAskSrc() == "DEALERWEB_REPO") {
   	        	ordertypeAsk = "FAS";
   	        	ordertypeBid = "FOK";
   	        } else if (best.getBidSrc() == "DEALERWEB_REPO") {
   	        	ordertypeAsk = "FOK";
   	        	ordertypeBid = "FAS";   	        	
   	        } else {
   	        	ordertypeAsk = "FAK";
   	        	ordertypeBid = "FAK";
   	        }
   	            	      	  
              if (LOGGER.isLoggable(Level.INFO)) {
                  ApplicationLogging.logAsync(LOGGER, Level.INFO, "AON instrument detected for " + best.getId() + 
                                             ", using exact bid size: " + orderBidSize + ", using exact ask size: " + orderAskSize);
              }
          } else {
              // For regular instruments, we can use the minimum of ask and bid sizes
              orderBidSize = Math.min(best.getAskSize(), best.getBidSize());
              orderAskSize = orderBidSize; 
             
              ordertypeAsk = "FAK";
              ordertypeBid = "FAK";
          }
	        
    	  // Place the orders using the looked-up trader IDs
 	        addOrder(best.getAskSrc(), askTrader, askVenueInstrument, "Buy", orderAskSize, 
	                best.getAsk(), "Limit", ordertypeAsk);
	        addOrder(best.getBidSrc(), bidTrader, bidVenueInstrument, "Sell", orderBidSize, 
	                best.getBid(), "Limit", ordertypeBid);
	        
	        // Record that we've traded this instrument
	        lastTradeTimeByInstrument.put(tradingKey, currentTime);
          if (LOGGER.isLoggable(Level.INFO)) {
            ApplicationLogging.logAsync(LOGGER, Level.INFO, "Recorded trade for " + tradingKey + 
                     " at " + new java.util.Date(currentTime));
          }
	    }
	}
	
	// Add this method to enable/disable continuous trading
	public void setContiguousTradingEnabled(boolean enabled) {
	    this.continuousTradingEnabled = enabled;
      if (LOGGER.isLoggable(Level.INFO)) {
	      ApplicationLogging.logAsync(LOGGER, Level.INFO, "Continuous trading " + (enabled ? "enabled" : "disabled"));
      }
	}
  /**
   * Handles changes to the order chain.
   * For new records, sets up subscriptions to receive updates.
   */
  public void onSupply(MkvChain chain, String record, int pos,
      MkvChainAction action) {
        if (LOGGER.isLoggable(Level.FINE)) {
          ApplicationLogging.logAsync(LOGGER, Level.FINE, "Order chain update: chain=" + chain.getName() + 
                   ", record=" + record + 
                   ", pos=" + pos + 
                   ", action=" + action);
        }
    switch (action.intValue()) {
    case MkvChainAction.INSERT_code:
    case MkvChainAction.APPEND_code:
      // For new records, subscribe to receive updates
      ApplicationLogging.logAsync(LOGGER, Level.INFO, "New record in chain, subscribing: " + record);
      subscribeToRecord(record);
      break;
    case MkvChainAction.SET_code:
      // For a SET action (chain is being completely redefined),
      // subscribe to all records in the chain
      ApplicationLogging.logAsync(LOGGER, Level.INFO, "Chain SET action, subscribing to all records");
      for (Iterator iter = chain.iterator(); iter.hasNext();) {
        String recName = (String) iter.next();
        ApplicationLogging.logAsync(LOGGER, Level.INFO, "Subscribing to chain record: " + recName);
        subscribeToRecord(recName);
      }
      break;
    case MkvChainAction.DELETE_code:
    ApplicationLogging.logAsync(LOGGER, Level.FINE, "Ignoring DELETE action for record: " + record);  
      break;
    }
  }

  /**
   * Sets up a subscription to an order record.
   * This allows receiving updates for the record.
   * 
   * @param record The name of the record to subscribe to
   */
  private void subscribeToRecord(String record) {
    try {
      ApplicationLogging.logAsync(LOGGER, Level.INFO, "Subscribing to record: " + record);
            
      // Get the record object
      MkvRecord rec = Mkv.getInstance().getPublishManager().getMkvRecord(record);
      
      // Subscribe to receive updates for the configured fields
      rec.subscribe(MarketDef.ORDER_FIELDS, this);
      ApplicationLogging.logAsync(LOGGER, Level.INFO, "Successfully subscribed to record: " + record);
    } catch (Exception e) {
      ApplicationLogging.logAsync(LOGGER, Level.SEVERE, "Error subscribing to record: " + record + 
                   ", error: " + e.getMessage(), e);
      e.printStackTrace();
    }
  }
  
//Add this method to the OrderManagement class
private void initializeHeartbeat() {
   heartbeatScheduler.scheduleAtFixedRate(() -> {
       try {
           // Log basic system and trading status
           Runtime runtime = Runtime.getRuntime();
           long usedMemory = runtime.totalMemory() - runtime.freeMemory();
           long freeMemory = runtime.freeMemory();
           
           // Gather trading statistics
           int instrumentCount = instrumentSubscriber != null ? 
               instrumentSubscriber.getInstrumentCount() : 0;
           int cachedOrders = orders.size();
           
           String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
           
           // Prepare heartbeat log message
           // Prepare heartbeat message using concatenation instead of String.format
           String heartbeatMessage = timestamp + " HEARTBEAT: " +
               "Instruments=" + instrumentCount + ", " +
               "Cached Orders=" + cachedOrders + ", " +
               "Memory (Used/Free)=" + usedMemory + "/" + freeMemory + " bytes, " +
               "Continuous Trading=" + continuousTradingEnabled + ", " +
               "Latest Best Prices=" + latestBestByInstrument.size();
           
           // Log the heartbeat
           ApplicationLogging.logAsync(LOGGER, Level.INFO, heartbeatMessage);
           System.out.println(heartbeatMessage);
           
       } catch (Exception e) {
           ApplicationLogging.logAsync(LOGGER, Level.WARNING, 
               "Error in heartbeat logging: " + e.getMessage(), e);
       }
   }, 30, 30, TimeUnit.SECONDS); // Run every 1 minute
   
   // Add a shutdown hook to properly close the heartbeat scheduler
   Runtime.getRuntime().addShutdownHook(new Thread(() -> {
       ApplicationLogging.logAsync(LOGGER, Level.INFO, "Shutting down heartbeat scheduler");
       heartbeatScheduler.shutdown();
       try {
           if (!heartbeatScheduler.awaitTermination(5, TimeUnit.SECONDS)) {
               heartbeatScheduler.shutdownNow();
           }
       } catch (InterruptedException e) {
           heartbeatScheduler.shutdownNow();
           Thread.currentThread().interrupt();
       }
   }));
}
  
  private void logStatistics() {
    AsyncLoggingManager manager = AsyncLoggingManager.getInstance();
    ApplicationLogging.logAsync(LOGGER, Level.INFO, 
          "Logging stats: queued=" + manager.getMessagesQueued() + 
          ", processed=" + manager.getMessagesProcessed() + 
          ", overflows=" + manager.getQueueOverflows() + 
          ", queueSize=" + manager.getCurrentQueueSize());
}

  /**
   * Sets up a shutdown hook to cancel outstanding orders on exit.
   */
  private void setupShutdownHook() {
      Runtime.getRuntime().addShutdownHook(new Thread() {
          @Override
          public void run() {
            ApplicationLogging.logAsync(LOGGER, Level.INFO, "Shutdown hook triggered");
              
              // Cancel all outstanding orders
              for (MarketOrder order : orders.values()) {
                ApplicationLogging.logAsync(LOGGER, Level.INFO, "Cancelling order: reqId=" + order.getMyReqId());
//                  order.cancel();
              }
              
              // Log the shutdown process
              ApplicationLogging.logAsync(LOGGER, Level.INFO, "All orders cancelled");  
                          
              // Give some time for cancellations to complete
              try {
                  Thread.sleep(2000);
              } catch (InterruptedException e) {
                  Thread.currentThread().interrupt();
              }
              AsyncLoggingManager.getInstance().shutdown();
              ApplicationLogging.logAsync(LOGGER, Level.INFO, "Shutdown cleanup complete");
          }
      });
  }
}