package com.iontrading.samples.advanced.orderManagement;

import com.iontrading.mkv.Mkv;
import com.iontrading.mkv.MkvComponent;
import com.iontrading.mkv.MkvObject;
import com.iontrading.mkv.MkvPattern;
import com.iontrading.mkv.MkvRecord;
import com.iontrading.mkv.MkvSupply;
import com.iontrading.mkv.enums.MkvObjectType;
import com.iontrading.mkv.enums.MkvPlatformEvent;
import com.iontrading.mkv.events.MkvPlatformListener;
import com.iontrading.mkv.events.MkvPublishListener;
import com.iontrading.mkv.events.MkvRecordListener;
import com.iontrading.mkv.exceptions.MkvException;
import com.iontrading.mkv.qos.MkvQoS;

import java.util.EnumMap;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import java.util.logging.Logger;
import java.util.logging.Level;

public class InstrumentSubscriber {

    private static final Logger LOGGER = Logger.getLogger(InstrumentSubscriber.class.getName());
    
    private static final String CM_SOURCE = "VMO_REPO_US";
    private static final String INSTRUMENT_PATTERN = "USD.CM_INSTRUMENT." + CM_SOURCE + ".";

    // Enum to standardize field names for type-safe lookups
    public enum InstrumentField {
        ID, ID0, ID1, ID2, ID3, ID4, ID5, ID6, ID7, ID8, ID9,
        SRC0, SRC1, SRC2, SRC3, SRC4, SRC5, SRC6, SRC7, SRC8, SRC9
    }
    
    private final Map<String, EnumMap<InstrumentField, Object>> instrumentData = new ConcurrentHashMap<>();
    private boolean dataLoaded = false;
    private List<Runnable> dataLoadedCallbacks = new ArrayList<>();
    private long lastLogTime = System.currentTimeMillis();
    private int recordCounter = 0;
    
    /** Creates a new instance of InstrumentSubscriber */
    public InstrumentSubscriber(String[] args) {
        LOGGER.info("Starting InstrumentSubscriber initialization");
        MkvQoS qos = new MkvQoS();
        qos.setArgs(args);
        qos.setPlatformListeners(new MkvPlatformListener[] {new PlatformListener()});
        try {
            LOGGER.info("About to start Mkv for InstrumentSubscriber");
            Mkv mkv = Mkv.start(qos);
            LOGGER.info("Successfully started Mkv for InstrumentSubscriber");
        } catch (MkvException e) {
            LOGGER.log(Level.SEVERE, "Failed to start Mkv for InstrumentSubscriber", e);
            e.printStackTrace();
        }
    }

    /**
     * Register a callback to be executed when instrument data is fully loaded
     */
    public synchronized void registerDataLoadedCallback(Runnable callback) {
        if (dataLoaded) {
            // If data is already loaded, execute callback immediately
            LOGGER.info("Data already loaded, executing callback immediately");
            callback.run();
        } else {
            // Otherwise, add to the list of callbacks
            LOGGER.info("Data not yet loaded, adding callback to queue");
            dataLoadedCallbacks.add(callback);
        }
    }
    
    /**
     * Check if instrument data is fully loaded
     */
    public synchronized boolean isDataLoaded() {
        return dataLoaded;
    }
    
    /**
     * Force data loaded notification (used by timeout mechanism)
     */
    public synchronized void forceDataLoaded() {
        if (!dataLoaded) {
            LOGGER.info("Forcing dataLoaded=true with " + instrumentData.size() + " instruments loaded");
            notifyDataLoaded();
        } else {
            LOGGER.info("Data already loaded, ignoring force request");
        }
    }
    
    /**
     * Called internally when data loading is complete
     */
    private synchronized void notifyDataLoaded() {
        if (dataLoaded) {
            LOGGER.info("Data already loaded, ignoring duplicate notification");
            return;
        }
        
        dataLoaded = true;
        LOGGER.info("Setting dataLoaded=true, executing " + dataLoadedCallbacks.size() + " callbacks");
        
        // Execute all registered callbacks
        int callbackIndex = 0;
        for (Runnable callback : dataLoadedCallbacks) {
            try {
                LOGGER.info("Executing callback #" + (++callbackIndex));
                callback.run();
                LOGGER.info("Callback #" + callbackIndex + " executed successfully");
            } catch (Exception e) {
                LOGGER.log(Level.SEVERE, "Error executing callback #" + callbackIndex, e);
                e.printStackTrace();
            }
        }
        
        // Clear the callbacks list
        dataLoadedCallbacks.clear();
        LOGGER.info("All callbacks executed and cleared");
    }
    
    public String getInstrumentFieldBySourceString(String instrumentId, String sourceId) {
        LOGGER.info("Looking up native instrument for ID: " + instrumentId + ", Source: " + sourceId);

        if (instrumentId == null || sourceId == null || instrumentId.isEmpty() || sourceId.isEmpty()) {
            LOGGER.warning("Invalid instrument or source ID");
            return null;
        }
        
        try {
            // Directly access the data using instrumentId as key
            EnumMap<InstrumentField, Object> data = instrumentData.get(instrumentId);
            
            if (data == null) {
                LOGGER.warning("No data found for instrument: " + instrumentId);
                return null;
            }
            
            // Find the source index by comparing string values
            int sourceIndex = -1;
            for (int i = 0; i < 10; i++) {  // Assuming up to 10 sources (Src0-Src9)
                try {
                    InstrumentField srcField = InstrumentField.valueOf("SRC" + i);
                    String src = (String) data.get(srcField);
                    if (sourceId.equals(src)) {
                        sourceIndex = i;
                        break;
                    }
                } catch (Exception e) {
                    // Skip invalid field names
                    continue;
                }
            }
            
            if (sourceIndex == -1) {
                LOGGER.warning("Source not found: " + sourceId + " for instrument: " + instrumentId);
                return null;
            }
            
            // Get the native instrument ID for this source
            InstrumentField idField = InstrumentField.valueOf("ID" + sourceIndex);
            String nativeId = (String) data.get(idField);
            
            LOGGER.info("Found native instrument: " + nativeId + " for ID: " + instrumentId + ", Source: " + sourceId);
            return nativeId;
        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "Error in getInstrumentFieldBySourceString", e);
            e.printStackTrace();
            return null;
        }
    }    
   
    /**
     * Get total number of instruments loaded
     */
    public int getInstrumentCount() {
        return instrumentData.size();
    }

    private class DataListener implements MkvRecordListener {
        @Override
        public void onPartialUpdate(MkvRecord mkvRecord, MkvSupply mkvSupply, boolean isSnapshot) {
            // Process partial updates for instrument data
            processInstrumentUpdate(mkvRecord, mkvSupply, isSnapshot);
        }

        @Override
        public void onFullUpdate(MkvRecord mkvRecord, MkvSupply mkvSupply, boolean isSnapshot) {
            processInstrumentUpdate(mkvRecord, mkvSupply, isSnapshot);
        }
        
        private void processInstrumentUpdate(MkvRecord mkvRecord, MkvSupply mkvSupply, boolean isSnapshot) {
            try {
                recordCounter++;
                
                // Periodic logging to avoid flooding
                long currentTime = System.currentTimeMillis();
                if (currentTime - lastLogTime > 5000) {  // Log every 5 seconds
                    LOGGER.info("Processed " + recordCounter + " instrument records so far");
                    lastLogTime = currentTime;
                }
                
//                String recordName = mkvRecord.getName();
                // Create an EnumMap for type-safe, efficient storage
                EnumMap<InstrumentField, Object> recordData = new EnumMap<>(InstrumentField.class);
                String instrumentId = null;
                
                // Populate the map with field names and values
                int cursor = mkvSupply.firstIndex();
                while (cursor != -1) {

                    try {
                        // Convert string field names to enum (e.g., "Id0" -> ID0)
//                        InstrumentField field = InstrumentField.valueOf(fieldName.toUpperCase());
                        String fieldName = mkvRecord.getMkvType().getFieldName(cursor);
                        Object fieldValue;
                        if (fieldName.startsWith("Id") || fieldName.startsWith("Src")) {
                            fieldValue = mkvSupply.getString(cursor);
                        } else {
                            fieldValue = mkvSupply.getObject(cursor);
                        }
                        
                        // Check if this is the main instrument ID field
                        if ("Id".equals(fieldName)) {
                            instrumentId = (String) fieldValue;
                            LOGGER.fine("Found instrument ID: " + instrumentId);
                        }
                        // Convert string field names to enum (e.g., "Id0" -> ID0)
                        try {
                            InstrumentField field = InstrumentField.valueOf(fieldName.toUpperCase());
                            recordData.put(field, fieldValue);
//                            LOGGER.fine("Found instrument ID: " + fieldValue.toString());
                        } catch (IllegalArgumentException e) {
                            // Skip fields that don't match our enum
                        }
                    } catch (IllegalArgumentException e) {
                        // Skip fields that don't match our enum
                    }
                    cursor = mkvSupply.nextIndex(cursor);
                }
                
                // Store the record data using record name as key
                instrumentData.put(instrumentId, recordData);
                
//                // Log first few instruments in detail
//                if (instrumentData.size() <= 5) {
//                    LOGGER.info("Added instrument: " + instrumentId + " (total: " + instrumentData.size() + ")");
//                }
            } catch (Exception e) {
                LOGGER.log(Level.WARNING, "Error processing instrument update", e);
                e.printStackTrace();
            }
        }
    }

    private class PlatformListener implements MkvPlatformListener {
        @Override
        public void onComponent(MkvComponent component, boolean start) {
//            LOGGER.fine("Component event: " + component.getName() + ", start: " + start);
        }

        @Override
        public void onConnect(String component, boolean start) {
//            LOGGER.fine("Connect event: " + component + ", start: " + start);
        }

        @Override
        public void onMain(MkvPlatformEvent event) {
//            LOGGER.info("Platform event: " + event);
            if (event.equals(MkvPlatformEvent.START)) {
                LOGGER.info("Mkv platform started, adding publish listener");
                Mkv.getInstance().getPublishManager().addPublishListener(new PublishListener());
            }
        }
    }

    private class PublishListener implements MkvPublishListener {

    	public void onPublish(MkvObject mkvObject, boolean start, boolean download) {
            if ((start) && (mkvObject.getName().toString().equals(INSTRUMENT_PATTERN)) && 
                    (mkvObject.getMkvObjectType().equals(MkvObjectType.PATTERN))) {
                try {
                    LOGGER.info("Found instrument pattern: " + mkvObject.getName());
                    MkvRecordListener listener = new DataListener();
                    String[] fields = {"Id", "Id0", "Id1", "Id2", "Id3", "Id4", "Id5", "Id6", "Id7", "Id8", "Id9",
                                     "Src0", "Src1", "Src2", "Src3", "Src4", "Src5", "Src6", "Src7", "Src8", "Src9"};
                    ((MkvPattern) mkvObject).subscribe(fields, listener);
                    LOGGER.info("Subscribed to instrument pattern: " + mkvObject.getName());
                } catch (Exception e) {
                    LOGGER.log(Level.SEVERE, "Error subscribing to instrument pattern", e);
                    e.printStackTrace();
                }
            }
        }

        public void onPublishIdle(String component, boolean start) {
//            LOGGER.info("PublishIdle event: " + component + ", start: " + start);
            if (!start) {
                // Look for the instrument pattern
                MkvObject mkvObj = Mkv.getInstance().getPublishManager().getMkvObject(INSTRUMENT_PATTERN);
                if ((mkvObj != null) && (mkvObj.getName().toString().equals(INSTRUMENT_PATTERN)) 
                		&& (mkvObj.getMkvObjectType().equals(MkvObjectType.PATTERN))) {
                    try {
                        LOGGER.info("Found instrument pattern during idle: " + mkvObj.getName());
                        MkvRecordListener listener = new DataListener();
                        String[] fields = {"Id", "Id0", "Id1", "Id2", "Id3", "Id4", "Id5", "Id6", "Id7", "Id8", "Id9",
                                         "Src0", "Src1", "Src2", "Src3", "Src4", "Src5", "Src6", "Src7", "Src8", "Src9"};
                        ((MkvPattern) mkvObj).subscribe(fields, listener);
                        LOGGER.info("Subscribed to instrument pattern at idle");
                    } catch (Exception e) {
                        LOGGER.log(Level.SEVERE, "Error subscribing to instrument pattern during idle", e);
                        e.printStackTrace();
                    }
                }
                
                // Check if we have enough instruments to consider data loading complete
                if (instrumentData.size() > 2000 && !dataLoaded) {
                    LOGGER.info("Received " + instrumentData.size() + " instruments, considering data loading complete");
                    notifyDataLoaded();
                }
                
                // If this is the end of all downloads, notify data loaded
                if (component.equals(INSTRUMENT_PATTERN)) {
                    LOGGER.info("Instrument component download complete, notifying data loaded");
                    notifyDataLoaded();
                }
            }
        }

        @Override
        public void onSubscribe(MkvObject mkvObject) {
            // Not needed
        }
    }
}