package com.iontrading.samples.advanced.orderManagement;

import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class LogSetup {
    
    private static FileHandler fileHandler;
    private static SimpleFormatter formatter;
    
    /**
     * Initialize file logging for the application
     * @param logFileName The name of the log file
     */
    public static void setupFileLogging(String logFileName) {
        try {
            // Create the logs directory if it doesn't exist
            java.io.File logDir = new java.io.File("logs");
            if (!logDir.exists()) {
                logDir.mkdir();
            }
            
            // Set up the file handler
            fileHandler = new FileHandler("logs/" + logFileName, 10 * 1024 * 1024, 5, true);
            formatter = new SimpleFormatter();
            fileHandler.setFormatter(formatter);
            
            // Set global logging level
            Logger.getLogger("").setLevel(Level.INFO);
            
            // Add handler to the root logger
            Logger.getLogger("").addHandler(fileHandler);
            
            // Set up specific loggers for our classes with higher detail level
            Logger orderMgmtLogger = Logger.getLogger("com.iontrading.samples.advanced.orderManagement");
            orderMgmtLogger.setLevel(Level.FINE);
            
            Logger.getLogger("com.iontrading.samples.advanced.orderManagement").info("File logging initialized to: logs/" + logFileName);
            
        } catch (SecurityException | IOException e) {
            e.printStackTrace();
            System.err.println("Failed to initialize file logging: " + e.getMessage());
        }
    }
}