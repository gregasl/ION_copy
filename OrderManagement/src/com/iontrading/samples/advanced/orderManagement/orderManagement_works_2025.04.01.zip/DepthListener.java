/*
 * DepthListener
 *
 * The depth class listen for the best changes for a single instrument and notifies
 * the order manager the new prices.
 *
 */

package com.iontrading.samples.advanced.orderManagement;

import java.util.Properties;
import java.util.logging.Logger;

import com.iontrading.mkv.MkvRecord;
import com.iontrading.mkv.MkvSupply;
import com.iontrading.mkv.events.MkvRecordListener;
import com.iontrading.mkv.exceptions.MkvException;
import com.iontrading.mkv.helper.MkvSubscribeProxy;

/**
 * DepthListener listens for market depth updates for a specific instrument
 * and notifies the order manager when best prices change.
 * 
 * It uses MkvSubscribeProxy to efficiently map record fields to Java bean properties.
 */
public class DepthListener implements MkvRecordListener {

	// Add logger for debugging
	private static final Logger LOGGER = Logger.getLogger(DepthListener.class.getName());

	/**
	 * Shared proxy instance used to map MKV record fields to Best bean properties.
	 * This is static as it can be shared across all instances for the same record type.
	 */
	private static MkvSubscribeProxy proxy;

    // Reference to the IOrderManager interface
    private final IOrderManager orderManager;
	
	/**
	 * Initializes the MkvSubscribeProxy if it hasn't been initialized yet.
	 * The proxy maps MKV record field names to Java bean property names.
	 * 
	 * @param rec The MKV record to use for initialization
	 * @throws MkvException If the proxy initialization fails
	 */
	private static void initProxy(MkvRecord rec) throws MkvException {
		if (proxy == null) {
			LOGGER.info("Initializing MkvSubscribeProxy for DepthListener");
			
			// Define the mapping from MKV field names to Best bean property names
			Properties p = new Properties();
			p.setProperty("Id", "Id");           // Map Id field to Id property
			p.setProperty("Ask0", "ask");           // Map Ask0 field to ask property
			p.setProperty("AskSrc0", "askSrc");           // Map Ask0 field to ask property
			p.setProperty("AskSize0", "askSize");   // Map AskSize0 field to askSize property
			p.setProperty("AskSize0_Min", "askSizeMin");           // Map AskSize0_Min field to askSizemin property
			p.setProperty("Bid0", "bid");           // Map Bid0 field to bid property
			p.setProperty("BidSrc0", "bidSrc");           // Map Ask0 field to ask property
			p.setProperty("BidSize0", "bidSize");   // Map BidSize0 field to bidSize property
			p.setProperty("BidSize0_Min", "bidSizeMin");   // Map BidSize0_Min field to bidSizemin property
			
			System.out.println("Creating Proxy for DepthListener");
			
			// Create the proxy with the Best class and the field mappings
			proxy = new MkvSubscribeProxy(Best.class, p);
			
			LOGGER.info("MkvSubscribeProxy initialized successfully");
		}
	}

	/**
	 * Creates a new DepthListener for the specified instrument.
	 * 
	 * @param instrId The instrument ID to listen for
	 * @param manager The order manager to notify of best changes
	 */
	public DepthListener(IOrderManager manager) {
		this.orderManager = manager;
        LOGGER.info("Created DepthListener for pattern subscription");
	}


	/**
	 * This listener does not process partial updates, only full updates.
	 */
	public void onPartialUpdate(MkvRecord mkvRecord, MkvSupply mkvSupply,
			boolean isSnapshot) {
		// Not interested in partial updates
//		LOGGER.finest("Ignoring partial update");
	}

	/**
	 * Processes a full update for the depth record.
	 * Updates the Best object with the new prices and notifies the order manager.
	 */
	public void onFullUpdate(MkvRecord mkvRecord, MkvSupply mkvSupply,
			boolean isSnapshot) {
		try {
			// Initialize the proxy if not already initialized
			initProxy(mkvRecord);
			
            // Extract the instrument ID from the record name
            String recordName = mkvRecord.getName();
            
            // Create a Best object for this instrument
            Best best = new Best(recordName);
//            String instrumentId = best.getid();
            
			// Previous values for logging
			double prevAsk = best.getAsk();
			double prevBid = best.getBid();
			
			// Update the Best object with the new values from the record
			proxy.update(mkvRecord, mkvSupply, best);
			
//			// Log the depth update
//			System.out.println("DEPTH: Instrument {" + recordName
//					+ "} " + "Ask {" + best.getAsk() + " " + best.getAskSize()
//					+ "} " + "Bid {" + best.getBid() + " " + best.getBidSize()
//					+ "}");
			
//			// More detailed logging, especially for price changes
//			if (best.getAsk() != prevAsk || best.getBid() != prevBid) {
//				LOGGER.info("Price change for " + recordName + 
//						   ": Ask " + prevAsk + " -> " + best.getAsk() + 
//						   ", Bid " + prevBid + " -> " + best.getBid());
//			} else {
//				LOGGER.fine("Depth update (no price change) for " + recordName);
//			}
			
			// Notify the order manager of the best update
//			LOGGER.fine("Notifying order manager of best update");
			orderManager.best(best);
		} catch (Exception e) {
			LOGGER.severe("Error processing depth update: " + e.getMessage());
			e.printStackTrace();
		}
	}

}