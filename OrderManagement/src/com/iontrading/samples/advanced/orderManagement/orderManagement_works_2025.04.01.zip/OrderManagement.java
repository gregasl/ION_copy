/*
 * OrderManagement
 *
 * OrderManagement object starts the component, register the relevant listeners
 * then subscribes to the depths of the configured instruments and to the orders
 * chain.
 * The set up of the subscription is done in onPublishIdle in order to not perform
 * expensive calculations in the onPublish method.
 *
 * Requirements:
 * A CM compliant market gateway must be set up and the constants in the MarketDef
 * class have to be adjusted to use gateways publications.
 *
 * ION Trading U.K. Limited supplies this software code is for testing purposes
 * only. The scope of this software code is exclusively limited to the
 * demonstration of the structure of an application using the ION(tm) Common
 * Market and ION Trading U.K. Limited does not guarantee the correct behavior
 * of any deployed application using this software code.
 * This software code has not been thoroughly tested under all conditions.
 * ION, therefore, cannot guarantee or imply reliability, serviceability, or
 * function of this software.
 * Any use of this software outside of this defined scope is the sole
 * responsibility of the user.
 *
 * ION Trading ltd (2005)
 */

package com.iontrading.samples.advanced.orderManagement;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.logging.Logger;

import com.iontrading.mkv.Mkv;
import com.iontrading.mkv.MkvChain;
import com.iontrading.mkv.MkvFunction;
import com.iontrading.mkv.MkvObject;
import com.iontrading.mkv.MkvPattern;
import com.iontrading.mkv.MkvPublishManager;
import com.iontrading.mkv.MkvRecord;
import com.iontrading.mkv.MkvSupply;
import com.iontrading.mkv.enums.MkvChainAction;
import com.iontrading.mkv.enums.MkvObjectType;
import com.iontrading.mkv.events.MkvChainListener;
import com.iontrading.mkv.events.MkvFunctionCallEvent;
import com.iontrading.mkv.events.MkvFunctionCallListener;
import com.iontrading.mkv.events.MkvPublishListener;
import com.iontrading.mkv.events.MkvRecordListener;
import com.iontrading.mkv.exceptions.MkvException;
import com.iontrading.mkv.helper.MkvSupplyFactory;
import com.iontrading.mkv.qos.MkvQoS;

/**
 * OrderManagement is the main component of the system that:
 * 1. Initializes the MKV API
 * 2. Sets up subscriptions to market data (depths and order chain)
 * 3. Implements IOrderManager to manage the lifecycle of orders
 * 4. Can optionally automatically trade based on market conditions
 * 
 * It implements multiple listener interfaces to receive various types of events
 * from the MKV API.
 */
public class OrderManagement implements MkvPublishListener, MkvRecordListener,
    MkvChainListener, IOrderManager {

  // Add logger for debugging
  private static final Logger LOGGER = Logger.getLogger(OrderManagement.class.getName());

  // Instance of InstrumentSubscriber to load and access instrument data
  private static InstrumentSubscriber instrumentSubscriber;

  // Timeout for instrument data loading (in seconds)
  private static final int INSTRUMENT_DATA_TIMEOUT = 30;
  private static final String CM_SOURCE = "VMO_REPO_US";
  private static final String PATTERN = "USD.CM_DEPTH." + CM_SOURCE + ".";
  
  /**
   * Main method to start the application.
   * Initializes the MKV API and sets up subscriptions.
   */
  public static void main(String[] args) {
	LogSetup.setupFileLogging("orderManagement.log");

	LOGGER.info("Starting OrderManagement");
    LOGGER.info("Starting OrderManagement with file logging enabled");
    // Create the order management instance
    OrderManagement om = new OrderManagement();
    
    try {
    	
      // First, initialize the InstrumentSubscriber and wait for data to load
      LOGGER.info("Initializing InstrumentSubscriber");
      instrumentSubscriber = new InstrumentSubscriber(args);
      
      // Set up a force data loaded call after timeout
      Thread timeoutThread = new Thread(() -> {
          try {
              Thread.sleep(INSTRUMENT_DATA_TIMEOUT * 1000);
              if (!instrumentSubscriber.isDataLoaded()) {
                  LOGGER.warning("Timeout waiting for instrument data. Forcing data loaded notification.");
                  instrumentSubscriber.forceDataLoaded();
              }
          } catch (InterruptedException e) {
              LOGGER.fine("Timeout thread interrupted");
          }
      });
      timeoutThread.setDaemon(true);
      timeoutThread.start();
      
      // Register a callback for when data is loaded
      instrumentSubscriber.registerDataLoadedCallback(() -> {
          LOGGER.info("Instrument data loaded. Proceeding with order management.");
          // No need to make these calls here since they'll be triggered by onPublishIdle events
      });
      
   // Set up the Quality of Service for the MKV API
      MkvQoS qos = new MkvQoS();
      qos.setArgs(args);
      qos.setPublishListeners(new MkvPublishListener[] { om });

      LOGGER.info("Starting MKV API");
      // Start the MKV API if it hasn't been started already
      Mkv existingMkv = Mkv.getInstance();
      if (existingMkv == null) {
          Mkv.start(qos);
      } else {
          LOGGER.info("MKV API already started, just adding publish listeners");
          existingMkv.getPublishManager().addPublishListener(om);
      }

      // Wait for instrument data to be loaded, but with a timeout
      LOGGER.info("Waiting for instrument data to be loaded...");
      boolean dataLoaded = false;
      try {
          for (int i = 0; i < INSTRUMENT_DATA_TIMEOUT; i++) {
              if (instrumentSubscriber.isDataLoaded()) {
                  dataLoaded = true;
                  LOGGER.info("Instrument data loaded successfully.");
                  break;
              }
              Thread.sleep(1000); // Check once per second
          }
          
          if (!dataLoaded) {
              LOGGER.warning("Timeout waiting for instrument data. Proceeding anyway.");
          }
      } catch (InterruptedException e) {
          LOGGER.severe("Interrupted while waiting for instrument data: " + e.getMessage());
          Thread.currentThread().interrupt();
      }
            
      // FIRST, cancel any outstanding orders
      LOGGER.info("Cleaning up any outstanding orders");
//      om.cancelOutstandingOrders();
      
      // Set up permanent subscriptions to the depths and order chain
      LOGGER.info("Setting up depth subscriptions");
      om.subscribeToDepths();
    } catch (MkvException e) {
      LOGGER.severe("Failed to start: " + e.getMessage());
      e.printStackTrace();
    }
  }
    
  /**
   * Gets the native instrument ID for a source.
   * This delegates to the InstrumentSubscriber.
   * 
   * @param instrumentId The instrument identifier
   * @param sourceId The source identifier
   * @return The native instrument ID or null if not found
   */
  public static String getNativeInstrumentId(String instrumentId, String sourceId) {
    if (instrumentSubscriber != null) {
      return instrumentSubscriber.getInstrumentFieldBySourceString(instrumentId, sourceId);
    }
    LOGGER.warning("InstrumentSubscriber not initialized - cannot get native instrument ID");
    return null;
  }
  
  /**
   * Map to cache market orders by their request ID.
   * This allows tracking orders throughout their lifecycle.
   */
  private final Map orders = new HashMap();

  /**
   * Unique identifier for this instance of the application.
   * Used to identify orders placed by this component.
   */
  private final String applicationId;

  /**
   * Creates a new instance of OrderManagement.
   * Generates a unique application ID based on the current time.
   */
  public OrderManagement() {
    // Generate a hex representation of the current time (last 3 digits)
    // This provides a reasonably unique ID for this instance
    applicationId = "Java_Order_Manager"; 
    LOGGER.info("OrderManagement initialized with applicationId: " + applicationId);
    
    // Set up the shutdown hook
    setupShutdownHook();
  }

  /**
   * Returns the unique application ID for this instance.
   * This is used to identify orders placed by this component.
   */
  public String getApplicationId() {
    return applicationId;
  }

  /**
   * Gets the InstrumentSubscriber instance.
   * 
   * @return The InstrumentSubscriber or null if not initialized
   */
  public static InstrumentSubscriber getInstrumentSubscriber() {
      return instrumentSubscriber;
  }
  
  /**
   * Called when a publication event occurs.
   * This implementation doesn't handle individual publication events.
   */
  public void onPublish(MkvObject mkvObject, boolean pub_unpub, boolean dwl) {
    // Not handling individual publication events
    LOGGER.finest("Publication event for: " + mkvObject.getName());
  }

  /**
   * Called when a publication download is complete.
   * This is where we set up the order chain subscription and
   * potentially send an initial FAS order if configured.
   * 
   * @param component The component name
   * @param start Whether this is the start of idle time
   */
  public void onPublishIdle(String component, boolean start) {
    LOGGER.info("Publication idle for component: " + component + ", start: " + start);
  }

  /**
   * Sets up subscriptions to depth records using a pattern-based approach.
   * Subscribes to the consolidated market data from VMO_REPO_US.
   */
  public void subscribeToDepths() {
      // Subscribe to consolidated depth data from VMO_REPO_US regardless of what's in MarketDef.CM_SOURCE
      LOGGER.info("Setting up consolidated depth subscription using pattern: " + PATTERN);
      
      try {
          // Get the publish manager to access patterns
          MkvPublishManager pm = Mkv.getInstance().getPublishManager();
          
          // Look up the pattern object
          MkvObject obj = pm.getMkvObject(PATTERN);
          
          if (obj != null && obj.getMkvObjectType().equals(MkvObjectType.PATTERN)) {
              // Create a depth listener that will handle all instruments
        	  DepthListener depthListener = new DepthListener(this);
              
              // Subscribe to the pattern with the depth fields
              LOGGER.info("Found consolidated depth pattern, subscribing: " + PATTERN);
              ((MkvPattern) obj).subscribe(MarketDef.DEPTH_FIELDS, depthListener);
              
              LOGGER.info("Successfully subscribed to consolidated depth pattern");
          } else {
              LOGGER.warning("Consolidated depth pattern not found: " + PATTERN);
          }
              // Set up a publish listener to catch the pattern when it appears
              pm.addPublishListener(new MkvPublishListener() {
                  @Override
                  public void onPublish(MkvObject mkvObject, boolean pub_unpub, boolean dwl) { }
                  
                  @Override
                  public void onPublishIdle(String component, boolean start) {
                      if (!start) {
                          // Check again for the pattern when download is complete
                          if (obj != null && obj.getMkvObjectType().equals(MkvObjectType.PATTERN)) {
                              try {
                                  LOGGER.info("Found consolidated depth pattern during idle: " + PATTERN);
                                  DepthListener depthListener = new DepthListener(OrderManagement.this);
                                  ((MkvPattern) obj).subscribe(MarketDef.DEPTH_FIELDS, depthListener);
                                  LOGGER.info("Successfully subscribed to consolidated depth pattern during idle");
                              } catch (Exception e) {
                                  LOGGER.severe("Error subscribing to consolidated depth pattern during idle: " + e.getMessage());
                                  e.printStackTrace();
                              }
                          }
                      }
                  }
                  
                  @Override
                  public void onSubscribe(MkvObject mkvObject) {
                      // Not needed
                  }
              });
          }
       catch (Exception e) {
          LOGGER.severe("Error setting up depth subscriptions: " + e.getMessage());
          e.printStackTrace();
      }
  }
	    
  /**
   * Not interested in this event because our component is a pure subscriber
   * and is not supposed to receive requests for subscriptions.
   */
  public void onSubscribe(MkvObject mkvObject) {
    // No action needed - we are not a publisher
    LOGGER.finest("Subscription event for: " + mkvObject.getName());
  }

  /**
   * Caches a MarketOrder record using the request ID as key.
   * This allows us to track the order throughout its lifecycle.
   * 
   * @param order The MarketOrder to cache
   */
  private void addOrder(MarketOrder order) {
    LOGGER.info("Caching order: reqId=" + order.getMyReqId());
    orders.put(Integer.valueOf(order.getMyReqId()), order);
  }

  /**
   * Removes a MarketOrder object from the cache by request ID.
   * Called when an order is considered "dead".
   * 
   * @param reqId The request ID of the order to remove
   */
  public void removeOrder(int reqId) {
    LOGGER.info("Removing order from cache: reqId=" + reqId);
    orders.remove(Integer.valueOf(reqId));
  }

  /**
   * Retrieves a MarketOrder object from the cache by request ID.
   * 
   * @param reqId The request ID of the order to retrieve
   * @return The MarketOrder object or null if not found
   */
  public MarketOrder getOrder(int reqId) {
    MarketOrder order = (MarketOrder) orders.get(Integer.valueOf(reqId));
    LOGGER.fine("Retrieved order from cache: reqId=" + reqId + 
               ", found=" + (order != null));
    return order;
  }

  /**
   * The component doesn't need to listen to partial updates for records.
   */
  public void onPartialUpdate(MkvRecord mkvRecord, MkvSupply mkvSupply,
      boolean isSnap) {
    // Not interested in partial updates
    LOGGER.finest("Received partial update for record: " + mkvRecord.getName());
  }

  /**
   * Processes full updates for CM_ORDER records.
   * If the update is for an order placed by this component
   * (based on UserData and FreeText), forwards the update to the
   * appropriate MarketOrder object.
   */
  public void onFullUpdate(MkvRecord mkvRecord, MkvSupply mkvSupply,
      boolean isSnap) {
    try {
      // Get the UserData (contains our request ID) and FreeText (contains our application ID)
      String userData = mkvRecord.getValue("UserData").getString();
      String freeText = mkvRecord.getValue("FreeText").getString();
      
      // If this order wasn't placed by us, ignore it
      if ("".equals(userData) || !freeText.equals(getApplicationId())) {
        LOGGER.finest("Ignoring order update for non-matching order: " + 
                     mkvRecord.getName() + ", userData=" + userData + 
                     ", freeText=" + freeText);
        return;
      } else {
        // This is an order we placed - forward the update to the MarketOrder
        try {
          // Parse the request ID from the UserData
          int reqId = Integer.parseInt(userData);
          LOGGER.fine("Processing update for our order: reqId=" + reqId);
          
          // Get the corresponding MarketOrder from the cache
          MarketOrder order = getOrder(reqId);
          
          if (order != null) {
            // Forward the update to the order
            LOGGER.fine("Forwarding update to order: reqId=" + reqId);
            order.onFullUpdate(mkvRecord, mkvSupply, isSnap);
          } else {
            LOGGER.warning("Received update for unknown order: reqId=" + reqId);
          }
        } catch (Exception e) {
          LOGGER.severe("Error processing order update: " + e.getMessage());
          e.printStackTrace();
        }
      }
    } catch (Exception e) {
      LOGGER.severe("Error accessing order fields: " + e.getMessage());
      e.printStackTrace();
    }
  }

  /**
   * Notification that an order is no longer able to trade.
   * Removes the order from the cache.
   * 
   * Implementation of IOrderManager.orderDead()
   */
  public void orderDead(MarketOrder order) {
    System.out.println("Order {" + order.getOrderId() + "} is dead.");
    LOGGER.info("Order is dead: orderId=" + order.getOrderId() + 
               ", reqId=" + order.getMyReqId());
    
    // Remove the order from the cache
    removeOrder(order.getMyReqId());
  }
    
  /**
   * Cancels a specific order by its ID.
   * 
   * @param orderId The ID of the order to cancel
   */
  private void cancelOrder(String orderId) {
      try {
          LOGGER.info("Canceling order: " + orderId);
          
          // Get the cancel function from the gateway
          MkvPublishManager pmBTEC = Mkv.getInstance().getPublishManager();
          MkvFunction fnBTEC = pmBTEC.getMkvFunction("BTEC_REPO_US" + "_VCMIOrderDel");
          
          if (fnBTEC == null) {
              LOGGER.severe("Cancel function not found");
              return;
          }
          
          // Create arguments for the cancel function
          MkvSupply argsBTEC = MkvSupplyFactory.create(new Object[] {
              "TEST2",    // User
              orderId,           // OrderId
              ""                 // FreeText
          });
          
          // Call the cancel function
          fnBTEC.call(argsBTEC, new MkvFunctionCallListener() {
              public void onError(MkvFunctionCallEvent evt, byte errCode, String errStr) {
                  LOGGER.severe("Failed to cancel order " + orderId + ": " + errStr);
              }
              
              public void onResult(MkvFunctionCallEvent evt, MkvSupply result) {
                  LOGGER.info("Successfully canceled order: " + orderId);
              }
          });
          
          // Get the cancel function from the gateway
          MkvPublishManager pmDEAL = Mkv.getInstance().getPublishManager();
          MkvFunction fnDEAL = pmDEAL.getMkvFunction("BTEC_REPO_US" + "_VCMIOrderDel");
          
          if (fnDEAL == null) {
              LOGGER.severe("Cancel function not found");
              return;
          }
          
          // Create arguments for the cancel function
          MkvSupply argsDEAL = MkvSupplyFactory.create(new Object[] {
              "asldevtrd1",    // User
              orderId,           // OrderId
              ""                 // FreeText
          });
          
          // Call the cancel function
          fnDEAL.call(argsDEAL, new MkvFunctionCallListener() {
              public void onError(MkvFunctionCallEvent evt, byte errCode, String errStr) {
                  LOGGER.severe("Failed to cancel order " + orderId + ": " + errStr);
              }
              
              public void onResult(MkvFunctionCallEvent evt, MkvSupply result) {
                  LOGGER.info("Successfully canceled order: " + orderId);
              }
          });
          
      } catch (Exception e) {
          LOGGER.severe("Error canceling order " + orderId + ": " + e.getMessage());
          e.printStackTrace();
      }
  }
  
  /**
   * Adds an order for the given instrument, quantity, and other parameters.
   * If the order creation succeeds, stores the order in the internal cache.
   * 
   * Implementation of IOrderManager.addOrder()
   */
  public MarketOrder addOrder(String MarketSource, String TraderId, String instrId, String verb, double qty,
      double price, String type, String tif) {
    
//    LOGGER.info("Adding order: instrId=" + instrId + 
//               ", verb=" + verb + 
//               ", qty=" + qty + 
//               ", price=" + price + 
//               ", type=" + type + 
//               ", tif=" + tif);

    // Create the order using the static factory method
    MarketOrder order = MarketOrder.orderCreate(MarketSource, TraderId, instrId, verb, qty, price,
        type, tif, this);
    
    if (order != null) {
      // If creation succeeded, add the order to the cache
      addOrder(order);
      LOGGER.info("Order added successfully: reqId=" + order.getMyReqId() + ",  instrId= " + instrId);
    } else {
      LOGGER.warning("Failed to create order");
    }

    return order;
  }

  /**
   * Handles notification of a best price update.
   * If AGGRESS is true, may decide to place an order based on the update.
   * 
   * Implementation of IOrderManager.best()
   */
  public void best(Best best) {
//	    LOGGER.info("OrderManagement.best() called for instrument: " + best.getInstrumentId());
//	    LOGGER.info("Ask: " + best.getAsk() + ", Bid: " + best.getBid());
//	    LOGGER.info("AskSrc: " + best.getAskSrc() + ", BidSrc: " + best.getBidSrc());
//	    LOGGER.info("AskSizeMin: " + best.getAskSizeMin() + ", BidSizeMin: " + best.getBidSizeMin());
	    
    	
      if ((best.getAsk() > best.getBid()) && (best.getAskSizeMin() >= best.getBidSizeMin()) && 
    		  (best.getAskSrc().equals("DEALERWEB_REPO") || best.getAskSrc().equals("BTEC_REPO_US")) && 
    		  (best.getBidSrc().equals("DEALERWEB_REPO") || best.getBidSrc().equals("BTEC_REPO_US"))) {
//        LOGGER.info("Automatically aggressing: instrumentId=" + 
//        		 best.getInstrumentId() + ", GetID value: " +  
//        		 best.getId() +
//                   ", ask=" + best.getAsk() +
//                   ", askSize=" + best.getAskSize());
         
        String BTECInstrument = instrumentSubscriber.getInstrumentFieldBySourceString(best.getId(),"BTEC_REPO_US");
//        LOGGER.info("BTEC Instrument ID: instrumentId=" + BTECInstrument);
        String DEALInstrument = instrumentSubscriber.getInstrumentFieldBySourceString(best.getId(),"DEALERWEB_REPO");
//        LOGGER.info("DEALERWEB Instrument ID: instrumentId=" + DEALInstrument);
        double OrderSize = Math.min(best.getAskSize(), best.getBidSize());
        if (best.getAskSrc().equals("BTEC_REPO_US")) {
        	// Place a Fill-And-Kill (FAK) order to buy at the ask price
            addOrder(best.getAskSrc(),"TEST2", BTECInstrument, "Buy", OrderSize, 
                    best.getAsk(), "Limit", "FAK");
            addOrder(best.getBidSrc(),"asldevtrd1", DEALInstrument, "Sell", OrderSize, 
                    best.getAsk(), "Limit", "FAK");
        } else {
        	// Place a Fill-And-Kill (FAK) order to buy at the ask price
            addOrder(best.getAskSrc(),"asldevtrd1", DEALInstrument, "Buy", OrderSize, 
                    best.getAsk(), "Limit", "FAK");
            addOrder(best.getBidSrc(),"TEST2", BTECInstrument, "Sell", OrderSize, 
                    best.getAsk(), "Limit", "FAK");
        }
      }
  }

  /**
   * Handles changes to the order chain.
   * For new records, sets up subscriptions to receive updates.
   */
  public void onSupply(MkvChain chain, String record, int pos,
      MkvChainAction action) {
    LOGGER.fine("Order chain update: chain=" + chain.getName() + 
               ", record=" + record + 
               ", pos=" + pos + 
               ", action=" + action);
    
    switch (action.intValue()) {
    case MkvChainAction.INSERT_code:
    case MkvChainAction.APPEND_code:
      // For new records, subscribe to receive updates
      LOGGER.info("New record in chain, subscribing: " + record);
      subscribeToRecord(record);
      break;
    case MkvChainAction.SET_code:
      // For a SET action (chain is being completely redefined),
      // subscribe to all records in the chain
      LOGGER.info("Chain SET action, subscribing to all records");
      for (Iterator iter = chain.iterator(); iter.hasNext();) {
        String recName = (String) iter.next();
        LOGGER.fine("Subscribing to chain record: " + recName);
        subscribeToRecord(recName);
      }
      break;
    case MkvChainAction.DELETE_code:
      LOGGER.fine("Ignoring DELETE action for: " + record);
      break;
    }
  }

  /**
   * Sets up a subscription to an order record.
   * This allows receiving updates for the record.
   * 
   * @param record The name of the record to subscribe to
   */
  private void subscribeToRecord(String record) {
    try {
      LOGGER.fine("Setting up subscription to record: " + record);
      
      // Get the record object
      MkvRecord rec = Mkv.getInstance().getPublishManager().getMkvRecord(record);
      
      // Subscribe to receive updates for the configured fields
      rec.subscribe(MarketDef.ORDER_FIELDS, this);
      
      LOGGER.info("Successfully subscribed to record: " + record);
    } catch (Exception e) {
      LOGGER.severe("Failed to subscribe to record: " + record + 
                   ", error: " + e.getMessage());
      e.printStackTrace();
    }
  }
  
  /**
   * Sets up a shutdown hook to cancel outstanding orders on exit.
   */
  private void setupShutdownHook() {
      Runtime.getRuntime().addShutdownHook(new Thread() {
          @Override
          public void run() {
              LOGGER.info("Application shutting down, canceling outstanding orders");
//              cancelOutstandingOrders();
              
              // Give some time for cancellations to complete
              try {
                  Thread.sleep(2000);
              } catch (InterruptedException e) {
                  Thread.currentThread().interrupt();
              }
              
              LOGGER.info("Shutdown cleanup complete");
          }
      });
  }
}
