/*
 * Best
 *
 * Java bean representing the best for an instrument. 
 *
 */

package com.iontrading.samples.advanced.orderManagement;

/**
 * Best is a data container class representing the best bid and ask prices
 * for a specific instrument.
 * 
 * This is a simple Java bean with getters and setters to hold the
 * current market best prices and sizes.
 */
public class Best {
    
    /**
     * The instrument ID this Best object represents.
     * This is immutable once set in the constructor.
     */
    private final String instrumentId;
    
    /**
     * The CUSIP
     */
    private String Id;
    
    /**
     * The best ask (sell) price in the market.
     */
    private double ask;

    /**
     * The best ask source in the market.
     */
    private String askSrc;
    
    /**
     * The quantity available at the best ask price.
     */
    private double askSize;
        
    /**
     * The min quantity available at the best ask price.
     */
    private double askSizeMin;
    
    /**
     * The best bid (buy) price in the market.
     */
    private double bid;
    
    /**
     * The best bid source in the market.
     */
    private String bidSrc;    
    
    /**
     * The quantity available at the best bid price.
     */
    private double bidSize;

    /**
     * The min quantity available at the best bid price.
     */
    private double bidSizeMin;
    
    /**
     * Creates a new Best instance for the specified instrument.
     * 
     * @param instrumentId The ID of the instrument this Best represents
     */
    public Best(String instrumentId) {
        this.instrumentId = instrumentId;
        // Prices and sizes are initialized to 0.0 by default
    }

    /**
     * @return The instrument ID this Best represents
     */
    public String getInstrumentId() {
        return instrumentId;
    }
    
    /**
     * @return The instrument ID this Best represents
     */
    public String getId() {
        return Id;
    }
    
    public void setId(String Id) {
        this.Id = Id;
    }
        
    /**
     * @return The best ask (sell) price in the market
     */
    public double getAsk() {
        return ask;
    }

    /**
     * Sets the best ask (sell) price in the market.
     * 
     * @param ask The new ask price
     */
    public void setAskSrc(String askSrc) {
        this.askSrc = askSrc;
    }
    
    /**
     * @return The best ask (sell) price in the market
     */
    public String getAskSrc() {
        return askSrc;
    }

    /**
     * Sets the best ask (sell) price in the market.
     * 
     * @param ask The new ask price
     */
    public void setAsk(double ask) {
        this.ask = ask;
    }

    /**
     * @return The quantity available at the best ask price
     */
    public double getAskSize() {
        return askSize;
    }

    /**
     * Sets the quantity available at the best ask price.
     * 
     * @param askSize The new ask size
     */
    public void setAskSize(double askSize) {
        this.askSize = askSize;
    }

    /**
     * @return The quantity available at the best ask price
     */
    public double getAskSizeMin() {
        return askSizeMin;
    }

    /**
     * Sets the min quantity available at the best ask price.
     * 
     * @param askSize The new ask size
     */
    public void setAskSizeMin(double askSizeMin) {
        this.askSizeMin = askSizeMin;
    }
    
    /**
     * @return The best bid (buy) price in the market
     */
    public double getBid() {
        return bid;
    }

    /**
     * Sets the best bid (buy) price in the market.
     * 
     * @param bid The new bid price
     */
    public void setBid(double bid) {
        this.bid = bid;
    }


    /**
     * Sets the best bid source in the market.
     * 
     * @param bid The new bid source
     */
    public void setBidSrc(String bidSrc) {
        this.bidSrc = bidSrc;
    }
    
    /**
     * @return The best ask (sell) price in the market
     */
    public String getBidSrc() {
        return bidSrc;
    }    
    
    /**
     * @return The quantity available at the best bid price
     */
    public double getBidSize() {
        return bidSize;
    }

    /**
     * Sets the quantity available at the best bid price.
     * 
     * @param bidSize The new bid size
     */
    public void setBidSize(double bidSize) {
        this.bidSize = bidSize;
    }
    
    /**
     * Sets the min quantity available at the best bid price.
     * 
     * @param bidSize The new bid size
     */
    public void setBidSizeMin(double bidSizeMin) {
        this.bidSizeMin = bidSizeMin;
    }

    /**
     * @return The min quantity available at the best bid price
     */
    public double getBidSizeMin() {
        return bidSizeMin;
    }
    
    /**
     * Returns a string representation of this Best object,
     * showing the instrument ID and prices.
     */
    @Override
    public String toString() {
        return "Best{instrumentId='" + instrumentId + "', " +
               "bid=" + bid + "/" + bidSize + ", " +
               "ask=" + ask + "/" + askSize + "}";
    }
}
