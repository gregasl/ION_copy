/*
 * MarketOrder
 *
 * MarketOrder accomplishes two tasks: putting order on the market (through a 
 * static method that return a MarketOrder instance) and to implement the logic
 * for getting back from the gateway the response to the request for adding an
 * order and to listen for the updates of the order.
 * The onSupply method implements also the logic that decides if an order can
 * generate trades or is "dead".
 *
 * ION Trading U.K. Limited supplies this software code is for testing purposes
 * only. The scope of this software code is exclusively limited to the
 * demonstration of the structure of an application using the ION(tm) Common
 * Market and ION Trading U.K. Limited does not guarantee the correct behavior
 * of any deployed application using this software code.
 * This software code has not been thoroughly tested under all conditions.
 * ION, therefore, cannot guarantee or imply reliability, serviceability, or
 * function of this software.
 * Any use of this software outside of this defined scope is the sole
 * responsibility of the user.
 *
 * ION Trading ltd (2005)
 */

package com.iontrading.samples.advanced.orderManagement;

import com.iontrading.mkv.Mkv;
import com.iontrading.mkv.MkvFunction;
import com.iontrading.mkv.MkvPublishManager;
import com.iontrading.mkv.MkvRecord;
import com.iontrading.mkv.MkvSupply;
import com.iontrading.mkv.events.MkvFunctionCallEvent;
import com.iontrading.mkv.events.MkvFunctionCallListener;
import com.iontrading.mkv.events.MkvRecordListener;
import com.iontrading.mkv.exceptions.MkvException;
import com.iontrading.mkv.helper.MkvSupplyFactory;
import java.util.logging.Logger;

/**
 * The MarketOrder class represents an order in the market and handles:
 * 1. Order creation via gateway functions
 * 2. Order lifecycle management (monitoring updates)
 * 3. Communication with the IOrderManager when the order's state changes
 * 
 * Implements both MkvFunctionCallListener (to receive the response to order creation)
 * and MkvRecordListener (to receive ongoing updates about the order's state)
 */
public class MarketOrder implements MkvFunctionCallListener, MkvRecordListener {
  
  // Add logger for debugging
  private static final Logger LOGGER = Logger.getLogger(MarketOrder.class.getName());
  
  /**
   * An id that should be unique during the life of the component.
   * This is a simple counter implementation - in a production system,
   * the generation of unique identifiers would likely be more sophisticated.
   */
  private static int reqId = 0;

  /**
   * Creates a new market order by calling the VCMIOrderAdd181 function on the gateway.
   * This is the main entry point for creating orders and registering a listener for updates.
   * 
   * @param instrId The instrument identifier
   * @param verb The order direction ("Buy" or "Sell")
   * @param qty The quantity of the order
   * @param price The price of the order
   * @param type The order type (e.g., "Limit", "Market")
   * @param tif Time in force (e.g., "Day", "IOC", "FOK", "FAS", "FAK")
   * @param orderManager The order manager that will be notified of order events
   * @return A new MarketOrder object or null if creation failed
   */
  		  
  public static MarketOrder orderCreate(String MarketSource, String TraderId, String instrId, String verb,
      double qty, double price, String type, String tif,
      IOrderManager orderManager) {
    
    // Increment the request ID to ensure uniqueness
    reqId++;
    
    // Log the order creation attempt
    LOGGER.info(String.format("Creating order request #%d for %s %s %.2f @ %.2f (%s, %s)",
               reqId, verb, instrId, qty, price, type, tif));
    
    // Get the publish manager to access functions
    MkvPublishManager pm = Mkv.getInstance().getPublishManager();
    
    // Get the order add function from the ION gateway
    MkvFunction fn = pm.getMkvFunction(MarketSource + "_VCMIOrderAdd181");
    
    if (fn == null) {
      LOGGER.severe("Failed to get VCMIOrderAdd181 function from gateway");
      return null;
    }
    
    try {
      // The free text will contain the application ID to identify orders from this component
      String freeText = orderManager.getApplicationId();
      
      // Create a new MarketOrder object that will track this order
      MarketOrder order = new MarketOrder(reqId, instrId, verb, qty, price, tif, orderManager);
     
      // Create the function arguments for the order creation
      // This is specific to the VCMIOrderAdd181 function interface
      MkvSupply args = MkvSupplyFactory.create(new Object[] {
        TraderId,                                 // User                  
        instrId,                                        // InstrumentId          
        verb,                                           // Verb (Buy/Sell)                 
        Double.valueOf(price),                          // Price                 
        Double.valueOf(qty),                                // QtyShown (visible quantity)             
        Double.valueOf(qty),                                // QtyTot (total quantity)               
        type,                                           // Type (Limit, Market, etc.)                 
        tif,                                            // TimeInForce (DAY, IOC, FOK, etc.)          
        Integer.valueOf(0),                                 // IsSoft                
        Integer.valueOf(0),                                 // Attribute             
        "",                                             // CustomerInfo          
        MarketDef.getFreeText("" + reqId, freeText),    // FreeText (contains reqId and appId)             
        Integer.valueOf(0),                                 // StopCond              
        "",                                             // StopId                
        Double.valueOf(0)                                   // StopPrice             
      });
    
      System.out.println("Adding order {" + reqId + "} " 
          + "instrId {" + instrId + "} " 
          + "verb {" + verb + "} " 
          + "qty {" + qty + "} " 
          + "price {" + price + "}");
      
      // Additional debug logging
      LOGGER.fine("Order creation details: type=" + type + ", tif=" + tif + 
                 ", appId=" + freeText + ", reqId=" + reqId);
      
      // Call the function with this MarketOrder as the listener for the response
      fn.call(args, order);
      
      return order;
    } catch (MkvException e) {
      LOGGER.severe("Error creating order: " + e.getMessage());
      e.printStackTrace();
    }
    return null;
  }

  /**
   * Order manager that will be notified of order lifecycle events
   */
  private final IOrderManager orderCallback;

  /**
   * The instrument ID for this order
   */
  private final String instrId;

  /**
   * The order ID assigned by the market after creation
   */
  private String orderId;

  /**
   * The order verb (Buy/Sell)
   */
  private final String verb;

  /**
   * The request ID assigned during creation
   */
  private final int myReqId;

  /**
   * Error code if order creation failed
   */
  private byte errCode = (byte) 0;

  /**
   * Error description if order creation failed
   */
  private String errStr = "";

  /** 
   * Creates a new instance of MarketOrder
   * Private constructor - instances should be created via orderCreate()
   */
  private MarketOrder(int _reqId, String instrId, String verb, double qty,
      double price, String tif, IOrderManager callback) {
    this.myReqId = _reqId;
    this.verb = verb;
    this.orderCallback = callback;
    this.instrId = instrId;
    
    LOGGER.fine("MarketOrder instance created with reqId=" + _reqId);
  }

  /**
   * Called when the function call to create an order fails.
   * The order manager is notified that the order is "dead".
   */
  public void onError(MkvFunctionCallEvent mkvFunctionCallEvent,
      byte errCode, String errStr) {
    System.out.println("_VCMIOrderAdd181 Failure {" + myReqId + "} {"
        + errCode + "} {" + errStr + "}");
    
    // Add more detailed logging
    LOGGER.warning("Order creation failed: reqId=" + myReqId + 
                  ", errCode=" + errCode + ", errStr=" + errStr);
    
    // Save the error information
    this.errCode = errCode;
    this.errStr = errStr;
    
    // Notify the order manager that this order is dead
    orderCallback.orderDead(this);
  }

  /**
   * Called when the function call to create an order succeeds.
   * The order is now in the market and we'll start receiving updates.
   */
  public void onResult(MkvFunctionCallEvent mkvFunctionCallEvent,
      MkvSupply mkvSupply) {
    System.out.println("_VCMIOrderAdd181 OK result {" + myReqId + "}");
    
    // Add more detailed logging
    LOGGER.info("Order creation succeeded: reqId=" + myReqId);
    
    // Here we could parse the result if needed
  }

  /**
   * @return The instrument ID for this order
   */
  public String getInstrId() {
    return instrId;
  }

  /**
   * @return The verb (Buy/Sell) for this order
   */
  public String getVerb() {
    return verb;
  }

  /**
   * @return The error code if order creation failed
   */
  public byte getErrCode() {
    return errCode;
  }

  /**
   * @return The error description if order creation failed
   */
  public String getErrStr() {
    return errStr;
  }

  /**
   * @return The request ID for this order
   */
  public int getMyReqId() {
    return myReqId;
  }

  /**
   * @return The order ID assigned by the market
   */
  public String getOrderId() {
    return orderId;
  }

  /**
   * Sets the order ID assigned by the market
   */
  private void setOrderId(String oid) {
    LOGGER.fine("Setting order ID: reqId=" + myReqId + ", orderId=" + oid);
    orderId = oid;
  }

  /**
   * Not interested in partial updates for the order
   */
  public void onPartialUpdate(MkvRecord mkvRecord, MkvSupply mkvSupply,
      boolean param) {
    // Not interested in partial updates
    LOGGER.finest("Received partial update for order: reqId=" + myReqId);
  }

  /**
   * Process full updates for the order record.
   * This is where we track the order's lifecycle and detect when it's "dead".
   */
  public void onFullUpdate(MkvRecord mkvRecord, MkvSupply mkvSupply,
      boolean param) {
    try {
      // Check if the order is still active
      int active = mkvRecord.getValue("Active").getInt();
      boolean closed = (active == 0);
      
      // Get and store the order ID from the market
      setOrderId(mkvRecord.getValue("Id").toString());
      
//      // Get quantities for logging
//      String qtyHit = mkvRecord.getValue("QtyHit").toString();
//      String qtyTot = mkvRecord.getValue("QtyTot").toString();
//      String price = mkvRecord.getValue("Price").toString();

//      System.out.println("Got order update Id {" + getOrderId() + "} "
//          + "ReqId {" + getMyReqId() + "} " 
//          + "Verb {" + getVerb() + "} "
//          + "Price {" + price + "} "
//          + "QtyHit {" + qtyHit + "} "
//          + "QtyTot {" + qtyTot + "} "
//          + "Active {" + active + "} " 
//          + "Closed {" + closed + "}");
//      
//      // More detailed logging
//      LOGGER.info("Order update: orderId=" + getOrderId() + 
//                 ", reqId=" + getMyReqId() + 
//                 ", filled=" + qtyHit + "/" + qtyTot + 
//                 ", active=" + active);

      // If the order is closed, notify the order manager
      if (closed && orderCallback != null) {
        LOGGER.info("Order is now dead: orderId=" + getOrderId() + 
                   ", reqId=" + getMyReqId());
        orderCallback.orderDead(this);
      }
    } catch (Exception e) {
      LOGGER.severe("Error processing order update: " + e.getMessage());
      e.printStackTrace();
    }
  }
}